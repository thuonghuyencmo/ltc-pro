/* LT&C website. All editable content lives in content.json (edited from /admin). */
(function () {
'use strict';

/* ================== i18n & helpers ================== */
let L = 'vi';
try { const s = localStorage.getItem('ltc-lang'); if (s === 'en' || s === 'vi') L = s; } catch (e) {}
const t = (vi, en) => (L === 'en' ? en : vi);
const T = o => (o == null ? '' : typeof o === 'string' ? o : (L === 'en' ? (o.en || o.vi || '') : (o.vi || o.en || '')));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = u => (/^(https?:\/\/|mailto:|tel:)/i.test(u || '') ? u : '');
const ICON = {
  arrow: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  ext: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  phone: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>',
  mail: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
  pin: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>',
  cal: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
  clock: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  yt: '<svg class="ico" viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8zM10 15V9l5.2 3z"/></svg>',
  fb: '<svg class="ico" viewBox="0 0 24 24" fill="currentColor"><path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H8v4h2v8h4v-8h3l1-4h-4V8z"/></svg>',
  li: '<svg class="ico" viewBox="0 0 24 24" fill="currentColor"><path d="M4 9h4v12H4zM6 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm5 6h4v1.7A4.3 4.3 0 0 1 19 9c3 0 3.5 2 3.5 4.6V21h-4v-6.5c0-1.6 0-3.5-2-3.5s-2.5 1.6-2.5 3.4V21H11z"/></svg>'
};
const fmtDate = d => { if (!d) return ''; const p = String(d).split('-'); return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : d; };
const vis = a => (a || []).filter(x => x && !x.hidden);

/* ================== content ================== */
let C = null;
const exById = id => C.experts.find(e => e.id === id);
const domById = id => C.domains.find(d => d.id === id);
const solById = id => C.solutions.find(s => s.id === id);
const caseById = id => C.cases.find(c => c.id === id);
const newsById = id => C.news.find(n => n.id === id);
const visEx = ids => (ids || []).map(exById).filter(e => e && !e.hidden);

/* UI-only data */
const GAPS = [
  { id: 'a', k: { vi: 'Khoảng trống 1', en: 'Gap 1' }, name: { vi: 'Chiến lược – Thực thi', en: 'Strategy-to-Execution' }, d: { vi: 'Chiến lược có trên giấy nhưng chưa được chia thành mục tiêu, ngân sách và nhịp rà soát cho từng bộ phận.', en: 'Strategy exists on paper but is not broken into goals, budgets and review rhythms for each unit.' } },
  { id: 'b', k: { vi: 'Khoảng trống 2', en: 'Gap 2' }, name: { vi: 'Năng lực', en: 'Capability' }, d: { vi: 'Đội ngũ quản lý và nhân sự chưa đủ năng lực để dẫn dắt thay đổi; tri thức nằm ở cá nhân, chưa thành hệ thống.', en: 'Managers and staff lack the capability to lead change; knowledge sits with individuals.' } },
  { id: 'c', k: { vi: 'Khoảng trống 3', en: 'Gap 3' }, name: { vi: 'Tốc độ ra kết quả', en: 'Speed-to-Results' }, d: { vi: 'Quy trình chưa chuẩn hóa, quyết định chậm, cải tiến khó nhân rộng nên kết quả đến muộn hơn kỳ vọng.', en: 'Unstandardised processes, slow decisions and hard-to-scale improvements delay results.' } }
];
const REC = {
  'health-a': { s: ['smart-review', 'strategy'], dom: 'strategy', vi: 'Bệnh viện thường có định hướng chuyên môn rõ nhưng thiếu kế hoạch chiến lược gắn với ngân sách và chỉ tiêu cho từng khoa, phòng.', en: 'Hospitals often have a clear clinical direction but lack a strategic plan tied to budgets and departmental targets.' },
  'health-b': { s: ['od', 'ops'], dom: 'od', vi: 'Đội ngũ giỏi chuyên môn nhưng năng lực quản lý khoa phòng, chăm sóc khách hàng và đào tạo nội bộ chưa đồng đều.', en: 'Clinically strong teams, but uneven departmental management, patient experience and internal training.' },
  'health-c': { s: ['ops', 'smart-review'], dom: 'ops', vi: 'Chương trình chất lượng kéo dài; hồ sơ chuẩn JCI, ACHSI đã có nhưng chưa thành thói quen vận hành hằng ngày.', en: 'Quality programmes drag on; JCI and ACHSI documents exist but are not yet daily habits.' },
  'biz-a': { s: ['strategy', 'smart-review'], dom: 'strategy', vi: 'Kế hoạch kinh doanh có, nhưng mục tiêu chưa được chia xuống từng phòng ban và chưa có nhịp rà soát định kỳ.', en: 'A business plan exists, but goals are not cascaded and there is no review rhythm.' },
  'biz-b': { s: ['od', 'hr'], dom: 'od', vi: 'Doanh nghiệp tăng trưởng nhanh hơn năng lực quản lý cấp trung; tuyển dụng và đào tạo chạy theo sự vụ.', en: 'The business grows faster than middle-management capability; hiring and training are ad hoc.' },
  'biz-c': { s: ['ops', 'strategy'], dom: 'ops', vi: 'Quy trình phụ thuộc cá nhân, KPI đo chậm, cải tiến ở một nơi khó nhân rộng ra toàn hệ thống.', en: 'Processes depend on individuals, KPIs arrive late, improvements are hard to scale.' },
  'ipo-a': { s: ['ipo', 'strategy'], dom: 'finance', vi: 'Câu chuyện tăng trưởng chưa được chứng minh bằng mô hình kinh doanh và kế hoạch tài chính đủ thuyết phục nhà đầu tư.', en: 'The growth story is not yet backed by a convincing business model and financial plan.' },
  'ipo-b': { s: ['ipo', 'od'], dom: 'legal', vi: 'Bộ máy quản trị, kế toán, pháp chế chưa đạt chuẩn của một công ty đại chúng.', en: 'Governance, accounting and legal functions are not yet at public-company standard.' },
  'ipo-c': { s: ['ipo', 'ops'], dom: 'finance', vi: 'Lộ trình IPO kéo dài vì các hạng mục quản trị, pháp lý, tài chính đang chạy rời rạc.', en: 'The IPO timeline slips because governance, legal and finance run separately.' }
};
const QUIZ = [
  ['a', 'Mục tiêu chiến lược 3–5 năm được viết rõ và ban lãnh đạo hiểu giống nhau.', 'Our 3–5 year strategic goals are written down and leaders understand them the same way.'],
  ['a', 'Mỗi phòng ban có mục tiêu năm gắn trực tiếp với mục tiêu chiến lược.', 'Each department’s annual goals link directly to the strategic goals.'],
  ['a', 'Có cuộc họp rà soát tiến độ chiến lược định kỳ (tháng hoặc quý) dựa trên số liệu.', 'We review strategic progress regularly (monthly or quarterly) using data.'],
  ['a', 'Ngân sách và nguồn lực được phân bổ theo thứ tự ưu tiên chiến lược.', 'Budgets and resources are allocated by strategic priority.'],
  ['a', 'Nhân viên tuyến đầu biết công việc của mình đóng góp vào mục tiêu nào.', 'Front-line staff know which goal their work contributes to.'],
  ['b', 'Có khung năng lực cho từng nhóm vị trí trong tổ chức.', 'We have a competency framework for each job group.'],
  ['b', 'Quản lý cấp trung đủ năng lực dẫn dắt đội nhóm triển khai thay đổi.', 'Middle managers are able to lead their teams through change.'],
  ['b', 'Có lộ trình đào tạo gắn với vị trí và được thực hiện đều đặn.', 'Role-based training roadmaps exist and are delivered consistently.'],
  ['b', 'Tri thức và quy trình được lưu trữ, số hóa, không phụ thuộc vào một vài cá nhân.', 'Knowledge and processes are documented and digitised, not held by a few people.'],
  ['b', 'Có đội ngũ giảng viên hoặc người kèm cặp nội bộ.', 'We have internal trainers or coaches.'],
  ['c', 'Quy trình cốt lõi được chuẩn hóa (ISO hoặc chuẩn ngành như JCI) và được tuân thủ.', 'Core processes are standardised (ISO or sector standards such as JCI) and followed.'],
  ['c', 'Quyền hạn và trách nhiệm rõ ràng nên quyết định được đưa ra nhanh.', 'Authority and accountability are clear, so decisions are made quickly.'],
  ['c', 'KPI được đo bằng dữ liệu và cập nhật kịp thời.', 'KPIs are measured with data and updated on time.'],
  ['c', 'Một sáng kiến cải tiến thường có kết quả trong vòng một quý kể từ khi được duyệt.', 'An approved improvement usually shows results within one quarter.'],
  ['c', 'Văn hóa tổ chức khuyến khích học hỏi và chịu trách nhiệm với kết quả.', 'Our culture encourages learning and ownership of results.']
];
const NEWS_TYPES = { news: { vi: 'Tin LT&C', en: 'LT&C news' }, event: { vi: 'Sự kiện', en: 'Events' }, press: { vi: 'Báo chí', en: 'Press' }, insight: { vi: 'Góc nhìn', en: 'Insights' } };
const D4 = [['diagnose', 'Diagnose', { vi: 'Chẩn đoán', en: 'Diagnose' }], ['design', 'Design', { vi: 'Thiết kế', en: 'Design' }], ['deploy', 'Deploy', { vi: 'Triển khai', en: 'Deploy' }], ['drive', 'Drive Result', { vi: 'Tạo kết quả', en: 'Drive results' }]];

const state = { dom: 0, ind: 'health', gap: 'a', logoTab: 'health', exf: 'all', caseInd: 'all', newsType: 'all', q: [], qi: 0, qdone: false };

/* ================== shared blocks ================== */
const initials = n => String(n).replace(/^(TS\.\s*BS\.|TS\.|BS\.|Bà|Ông|Ms\.|Mr\.|Dr\.)\s*/g, '').split(/\s+/).filter(Boolean).slice(-2).map(w => w[0]).join('');
const face = e => e.photo ? `<img src="${esc(e.photo)}" alt="${esc(T(e.name))}" loading="lazy">` : `<span class="mono">${esc(initials(T(e.name)))}</span>`;
const ppBtn = (e, small = true) => `<button class="pp" data-ex="${esc(e.id)}">${face(e)}<span>${esc(T(e.name))}${small ? `<small>${esc(T(e.role))}</small>` : ''}</span></button>`;
const go = h => { if (location.hash === '#' + h) { render(); scrollTo(0, 0); } else location.hash = h; };
const wl = d => T(d.wl).replace('|', ' ');

function wheelSVG() {
  const D = C.domains, cx = 300, cy = 300, n = D.length, step = 360 / n, gap = 0.9;
  const P = (r, a) => { const rad = a * Math.PI / 180; return [(cx + r * Math.cos(rad)).toFixed(2), (cy + r * Math.sin(rad)).toFixed(2)]; };
  const arc = (r1, r2, a0, a1) => { const [x1, y1] = P(r2, a0), [x2, y2] = P(r2, a1), [x3, y3] = P(r1, a1), [x4, y4] = P(r1, a0); return `M${x1} ${y1}A${r2} ${r2} 0 0 1 ${x2} ${y2}L${x3} ${y3}A${r1} ${r1} 0 0 0 ${x4} ${y4}Z`; };
  const label = (txt, r, a, size, weight, up) => { const [x, y] = P(r, a); const lines = String(txt).split('|'); const lh = size * 1.18;
    return `<text x="${x}" y="${y}" text-anchor="middle" font-size="${size}" font-weight="${weight}">` + lines.map((l, k) => `<tspan x="${x}" dy="${k === 0 ? (-(lines.length - 1) * lh / 2 + size * .35).toFixed(1) : lh.toFixed(1)}">${esc(up ? l.toUpperCase() : l)}</tspan>`).join('') + '</text>'; };
  let o = '', i = '';
  D.forEach((d, k) => {
    const mid = -90 + k * step, a0 = mid - step / 2 + gap, a1 = mid + step / 2 - gap, on = k === state.dom ? ' on' : '';
    o += `<g class="seg o${on}" data-k="${k}" tabindex="0" role="button" aria-label="${esc(T(d.name))}"><path d="${arc(198, 296, a0, a1)}"/>${label(T(d.wl), 247, mid, 15.5, 600)}</g>`;
    i += `<g class="seg i${on}" data-k="${k}" aria-hidden="true"><path d="${arc(116, 192, a0, a1)}"/>${label(T(d.vl), 154, mid, 11, 700, true)}</g>`;
  });
  return `<svg viewBox="-4 -4 608 608" role="group" aria-label="The Change Catalyst">${o}${i}<circle class="hub" cx="300" cy="300" r="108"/><circle cx="300" cy="268" r="40" fill="#fff"/><image href="img/ltc-mark.png" x="272" y="240" width="56" height="56"/><text class="hubt" x="300" y="338" text-anchor="middle" font-size="13.5">THE CHANGE</text><text class="hubt" x="300" y="356" text-anchor="middle" font-size="13.5">CATALYST</text></svg>`;
}
function domPanel() {
  const d = C.domains[state.dom];
  return `<div class="panel fade" id="dpanel"><span class="chip">${String(state.dom + 1).padStart(2, '0')} / ${String(C.domains.length).padStart(2, '0')} · ${esc(T(d.verb))}</span>
    <h3>${esc(T(d.name))}</h3><p class="k">${esc(T(d.sub))}</p><p class="muted">${esc(T(d.d))}</p>
    <ul class="ticks">${(T(d.s) || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul>
    <div class="people">${visEx(d.ex).map(e => ppBtn(e)).join('')}</div>
    <div><button class="link" data-go="chuyen-gia" data-exf="${esc(d.id)}">${t('Xem chuyên gia lĩnh vực này', 'See experts in this field')} ${ICON.arrow}</button></div></div>`;
}
function catalyst() {
  if (state.dom >= C.domains.length) state.dom = 0;
  return `<div class="cat"><div class="wheel" id="wheel">${wheelSVG()}</div><div>${domPanel()}
    <div class="dots" style="margin-top:22px" role="group">${C.domains.map((d, k) => `<button data-dk="${k}" aria-pressed="${k === state.dom}">${k + 1}. ${esc(wl(d))}</button>`).join('')}</div></div></div>`;
}
function setDom(k) {
  state.dom = +k;
  const w = document.getElementById('wheel'); if (w) w.innerHTML = wheelSVG();
  const p = document.getElementById('dpanel'); if (p) p.outerHTML = domPanel();
  document.querySelectorAll('[data-dk]').forEach(b => b.setAttribute('aria-pressed', +b.dataset.dk === state.dom));
}
function picker() {
  const r = REC[state.ind + '-' + state.gap] || REC['health-a'], dm = domById(r.dom);
  return `<div class="picker"><p class="q">${t('Tổ chức của tôi thuộc', 'My organisation is in')}
    <select id="selInd" aria-label="${t('Ngành', 'Industry')}">${C.industries.map(i => `<option value="${esc(i.id)}" ${i.id === state.ind ? 'selected' : ''}>${esc(T(i.name))}</option>`).join('')}</select>
    ${t('và đang vướng ở khoảng trống', 'and our biggest gap is')}
    <select id="selGap" aria-label="${t('Khoảng trống', 'Gap')}">${GAPS.map(g => `<option value="${g.id}" ${g.id === state.gap ? 'selected' : ''}>${esc(T(g.name))}</option>`).join('')}</select></p>
    <div class="rec fade"><div class="why"><b>${t('Chúng tôi thường thấy', 'What we often see')}</b>${esc(L === 'en' ? r.en : r.vi)}
      ${dm ? `<p style="margin-top:14px"><button class="link" data-go="linh-vuc" data-dom="${C.domains.indexOf(dm)}">${t('Lĩnh vực chuyên môn', 'Practice area')}: ${esc(wl(dm))} ${ICON.arrow}</button></p>` : ''}</div>
      <div class="sols">${r.s.map(solById).filter(Boolean).map(s => `<div class="sol"><span class="n">${t('Giải pháp', 'Solution')} ${esc(s.n)}</span><h4>${esc(T(s.name))}</h4><p class="muted" style="font-size:14px">${esc(T(s.tag))}</p><button class="link" data-go="giai-phap" data-sol="${esc(s.id)}" style="font-size:14px">${t('Xem cách làm', 'How we work')} ${ICON.arrow}</button></div>`).join('')}</div></div></div>`;
}
function bindPicker() {
  const a = document.getElementById('selInd'), b = document.getElementById('selGap'); if (!a) return;
  const up = () => { state.ind = a.value; state.gap = b.value; a.closest('.picker').outerHTML = picker(); bindPicker(); };
  a.onchange = up; b.onchange = up;
}
function logoWall(groups) {
  groups = groups || ['health', 'biz', 'eco'];
  const names = { health: t('Y tế', 'Healthcare'), biz: t('Doanh nghiệp', 'Businesses'), eco: t('Đối tác hệ sinh thái', 'Ecosystem partners') };
  if (!groups.includes(state.logoTab)) state.logoTab = groups[0];
  const list = g => vis(C.logos).filter(l => l.group === g);
  return `<div id="lw"><div class="tabs" role="group">${groups.map(g => `<button data-lt="${g}" aria-pressed="${state.logoTab === g}">${names[g]} · ${list(g).length}</button>`).join('')}</div>
    <div class="logos">${list(state.logoTab).map(l => `<div title="${esc(l.name)}"><img src="${esc(l.src)}" alt="${esc(l.name)}" loading="lazy"></div>`).join('')}</div></div>`;
}
const exHl = e => (T(e.hl) || []).filter(Boolean);
function exCard(e) {
  const d = e.dom && e.dom[0] ? domById(e.dom[0]) : null, hl = exHl(e);
  return `<button class="ex" data-ex="${esc(e.id)}"><div class="ph">${face(e)}</div><div><span class="tg">${esc(d ? wl(d) : T(e.role))}</span><h4>${esc(T(e.name))}</h4><p class="ttl">${esc(T(e.title) || T(e.role))}</p>${hl.length ? `<ul class="hl">${hl.slice(0, 3).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}</div></button>`;
}
function caseCard(c) {
  const ind = C.industries.find(i => i.id === c.industry), ch = T(c.challenge);
  return `<button class="case" data-go="${esc('du-an-' + c.id)}"><div class="lg">${c.logo ? `<img src="${esc(c.logo)}" alt="${esc(T(c.client))}" loading="lazy">` : ''}${T(c.status) ? `<span class="pill tagc">${esc(T(c.status))}</span>` : ''}</div>
    <div class="bd"><span class="cli">${esc(T(c.client))}</span><h3>${esc(T(c.title))}</h3>${ch ? `<p>${esc(ch.length > 150 ? ch.slice(0, 150) + '…' : ch)}</p>` : ''}
    <div style="display:flex;gap:6px;flex-wrap:wrap">${ind ? `<span class="pill b">${esc(T(ind.name))}</span>` : ''}${(c.solutions || []).slice(0, 2).map(solById).filter(Boolean).map(s => `<span class="pill">${esc(T(s.name))}</span>`).join('')}</div>
    <span class="go">${t('Xem dự án', 'View project')} ${ICON.arrow}</span></div></button>`;
}
function newsCard(n) {
  const typ = NEWS_TYPES[n.type] || NEWS_TYPES.news, url = safeUrl(n.url), hasBody = !!T(n.body);
  const action = hasBody ? `<button class="link" data-go="${esc('tin-' + n.id)}">${t('Đọc tiếp', 'Read more')} ${ICON.arrow}</button>`
    : url ? `<a class="link" href="${esc(url)}" target="_blank" rel="noopener">${n.type === 'press' ? t('Đọc bài gốc', 'Read the article') : t('Xem thêm', 'Read more')} ${ICON.ext}</a>`
    : (n.type === 'insight' ? `<span class="pill">${t('Sắp đăng', 'Coming soon')}</span>` : '');
  return `<article class="nw">${n.image ? `<div class="im"><img src="${esc(n.image)}" alt="" loading="lazy"></div>` : ''}<div class="meta2"><b>${esc(T(typ))}</b>${n.date ? `<span>${fmtDate(n.date)}</span>` : ''}${n.source ? `<span>· ${esc(n.source)}</span>` : ''}</div><h3>${esc(T(n.title))}</h3><p>${esc(T(n.excerpt))}</p>${action ? `<div>${action}</div>` : ''}</article>`;
}
const sortedNews = () => vis(C.news).slice().sort((a, b) => (b.date || '0').localeCompare(a.date || '0'));

function contactForm(id, compact) {
  return `<form class="form" id="${id}" novalidate>
    <div class="hp" aria-hidden="true"><label for="${id}-web">Website</label><input id="${id}-web" name="website" tabindex="-1" autocomplete="off"></div>
    <div class="fld"><label for="${id}-name">${t('Họ và tên', 'Full name')} *</label><input id="${id}-name" name="name" required autocomplete="name"></div>
    <div class="fld"><label for="${id}-org">${t('Tổ chức', 'Organisation')} *</label><input id="${id}-org" name="org" required autocomplete="organization"></div>
    <div class="fld"><label for="${id}-role">${t('Chức danh', 'Job title')}</label><input id="${id}-role" name="role" autocomplete="organization-title"></div>
    <div class="fld"><label for="${id}-phone">${t('Điện thoại', 'Phone')} *</label><input id="${id}-phone" name="phone" required type="tel" autocomplete="tel"></div>
    <div class="fld ${compact ? 'full' : ''}"><label for="${id}-email">Email *</label><input id="${id}-email" name="email" required type="email" autocomplete="email"></div>
    ${compact ? '' : `<div class="fld"><label for="${id}-ind">${t('Lĩnh vực hoạt động', 'Industry')}</label><select id="${id}-ind" name="industry">${C.industries.map(i => `<option>${esc(T(i.name))}</option>`).join('')}<option>${t('Khác', 'Other')}</option></select></div>`}
    <div class="fld full"><label for="${id}-need">${t('Giải pháp quan tâm', 'Solution of interest')}</label><select id="${id}-need" name="need"><option value="">${t('Chưa xác định, cần tư vấn', 'Not sure yet')}</option>${C.solutions.map(s => `<option>${esc(T(s.name))}</option>`).join('')}<option>${t('Học viện LT&C / Đào tạo', 'LT&C Academy / Training')}</option></select></div>
    <div class="fld full"><label for="${id}-msg">${t('Bài toán của tổ chức', 'Your challenge')}</label><textarea id="${id}-msg" name="msg" placeholder="${t('Ví dụ: Bệnh viện 300 giường muốn chuẩn bị JCI trong 18 tháng', 'e.g. A 300-bed hospital preparing for JCI within 18 months')}"></textarea></div>
    <div class="full" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap"><button class="btn gold" type="submit">${t('Gửi yêu cầu trao đổi', 'Request a conversation')} ${ICON.arrow}</button><span class="muted" style="font-size:13.5px">${t('LT&C phản hồi trong vòng 24 giờ làm việc. Thông tin được bảo mật.', 'LT&C replies within 24 business hours. Your details stay confidential.')}</span></div>
  </form>`;
}
/* Leads go to api.php on your own hosting. Inside the Claude preview they go to the page's database. */
async function saveLead(data) {
  try {
    const r = await fetch('api.php?action=lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    if (r.ok) { const j = await r.json().catch(() => null); if (j && j.ok) return true; }
  } catch (e) {}
  try {
    if (window.claude && window.claude.use) {
      const [db, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
      if (db && user) { const uid = await user.id(); if (uid) { await db.collection('leads/' + uid + '/items').add({ ...data, createdAt: new Date().toISOString() }); return true; } }
    }
  } catch (e) {}
  return false;
}
function bindForm(id, type, extra) {
  const f = document.getElementById(id); if (!f) return;
  f.onsubmit = async ev => {
    ev.preventDefault();
    f.querySelectorAll('.msg').forEach(m => m.remove());
    const fd = Object.fromEntries(new FormData(f).entries());
    const miss = [...f.querySelectorAll('[required]')].filter(i => !i.value.trim() || (i.type === 'email' && !/^\S+@\S+\.\S+$/.test(i.value)));
    const box = document.createElement('div'); box.className = 'msg';
    if (miss.length) { box.classList.add('err'); box.textContent = t('Vui lòng điền đủ các ô có dấu * (email đúng định dạng).', 'Please complete the fields marked * (with a valid email).'); f.appendChild(box); miss[0].focus(); return; }
    const btn = f.querySelector('[type=submit]'); btn.disabled = true;
    const ok = await saveLead({ type, lang: L, page: location.hash || '#trang-chu', ...fd, ...(extra ? extra() : {}) });
    btn.disabled = false;
    const ph = C.site.contact.phone, em = C.site.contact.email;
    if (ok) { box.classList.add('ok'); box.textContent = t('Đã ghi nhận yêu cầu. Chuyên gia LT&C sẽ liên hệ trong vòng 24 giờ làm việc.', 'Request received. An LT&C consultant will contact you within 24 business hours.'); f.reset(); }
    else { box.classList.add('err'); box.textContent = t(`Chưa gửi được từ trang này. Vui lòng gọi ${ph} hoặc email ${em}.`, `This page could not send your request. Please call ${ph} or email ${em}.`); }
    f.appendChild(box);
  };
}
function socialLinks() {
  const s = C.site.social || {};
  const items = [['zalo', 'Zalo', '<span>Zalo</span>'], ['facebook', 'Facebook', ICON.fb], ['youtube', 'YouTube', ICON.yt], ['linkedin', 'LinkedIn', ICON.li]].filter(([k]) => safeUrl(s[k]));
  return items.length ? `<div class="social">${items.map(([k, n, ic]) => `<a href="${esc(safeUrl(s[k]))}" target="_blank" rel="noopener" aria-label="${n}" title="${n}">${ic}</a>`).join('')}</div>` : '';
}
function contactLines() {
  const c = C.site.contact;
  return `<div class="contact-lines">
    <div class="cl">${ICON.phone}<span class="v">${esc(c.phone)}</span><button class="copy" data-copy="${esc(c.phone)}">${t('Chép', 'Copy')}</button></div>
    <div class="cl">${ICON.mail}<span class="v">${esc(c.email)}</span><button class="copy" data-copy="${esc(c.email)}">${t('Chép', 'Copy')}</button></div>
    <div class="cl">${ICON.pin}<span class="v">${esc(T(c.address))}${safeUrl(c.mapUrl) ? ` · <a href="${esc(c.mapUrl)}" target="_blank" rel="noopener" style="color:var(--gold)">${t('Bản đồ', 'Map')}</a>` : ''}</span><span></span></div>
    <div class="cl">${ICON.clock}<span class="v">${esc(T(c.hours))} · ${t('phản hồi trong 24 giờ làm việc', 'reply within 24 business hours')}</span><span></span></div>
    ${socialLinks()}</div>`;
}
function ctaEnd() {
  return `<section class="sec band" id="cta"><div class="wrap cta-end"><div><span class="eyebrow">${t('Bắt đầu', 'Get started')}</span>
    <h2 style="margin-top:14px">${t('Thay đổi bắt đầu từ <em class="g">một cuộc trò chuyện</em>', 'Change starts with <em class="g">a conversation</em>')}</h2>
    <p class="lead" style="margin-top:16px">${t('Đặt lịch 30 phút với chuyên gia LT&C để cùng nhìn rõ bài toán của tổ chức. Buổi trao đổi đầu tiên không tính phí.', 'Book 30 minutes with an LT&C expert to frame your challenge. The first conversation is free of charge.')}</p>${contactLines()}</div>
    <div>${contactForm('fEnd', true)}</div></div></section>`;
}
const pageHero = (crumb, title, lead) => `<section class="phero"><div class="wrap"><p class="crumb"><button data-go="trang-chu">${t('Trang chủ', 'Home')}</button> / ${crumb}</p><h1>${title}</h1>${lead ? `<p class="lead">${lead}</p>` : ''}</div></section>`;
function fourD() {
  const txt = { diagnose: t('Đánh giá mức trưởng thành của tổ chức, xác định ưu tiên chiến lược và lợi thế cạnh tranh cốt lõi.', 'Assess maturity, identify strategic priorities and core competitive advantages.'), design: t('Xây chiến lược toàn doanh nghiệp và chiến lược chức năng gắn với mục tiêu kinh doanh.', 'Develop enterprise-wide and functional strategies aligned with business objectives.'), deploy: t('Đồng hành triển khai bằng kế hoạch hành động, coaching, mentoring và chuyển giao năng lực.', 'Support implementation through action plans, coaching, mentoring and capability transfer.'), drive: t('Gắn hành vi, cách lãnh đạo và văn hóa mong muốn vào tổ chức để kết quả bền vững.', 'Embed behaviours, leadership practices and culture so results last.') };
  return `<div class="fourd">${D4.map(([k, en, vi], i) => `<div class="d4"><span class="n">D${i + 1}</span><h3>${en}</h3><h4>${esc(T(vi))}</h4><p>${txt[k]}</p></div>`).join('')}</div>`;
}
function ladder() {
  const R = [[t('Khuyến nghị chiến lược', 'Strategic recommendations'), t('Rà soát & điều chỉnh', 'Review & revise'), t('Chiến lược rõ ràng', 'Strategic clarity')], [t('Áp dụng / Học qua làm', 'Apply / learning by doing'), t('Đồng hành', 'Accompanying'), t('Năng lực lãnh đạo mạnh hơn', 'Stronger leadership')], [t('Phát triển năng lực', 'Capability development'), 'Coaching & Mentoring', t('Hiệu quả vận hành cao hơn', 'Better operational performance')], [t('Lãnh đạo tạm thời & quản lý vận hành', 'Interim leadership & operations'), t('Cộng sự', 'Associate'), t('Tăng trưởng bền vững', 'Sustainable growth')], [t('Đối tác chiến lược', 'Strategic partnership'), t('Đồng đầu tư', 'Co-invest'), t('Kết quả kinh doanh đột phá', 'Breakthrough results')]];
  return `<div class="ladder">${R.map((r, k) => `<div class="rung"><div><span class="lv">${t('Cấp', 'Level')} ${k + 1}</span><br><b>${r[0]}</b></div><span class="mid">${r[1]}</span><span class="out">${r[2]}</span></div>`).join('')}</div>`;
}

/* ================== views ================== */
const V = {};
const SVC_IC = {
  'smart-review': '<path d="M9 4h6M8 3h8v3H8zM6 5H5v16h14V5h-1"/><path d="M8 11h4M8 15h3"/><circle cx="15.5" cy="15.5" r="2.5"/><path d="m17.5 17.5 2 2"/>',
  strategy: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/><path d="m15 9 5-5M17 4h3v3"/>',
  od: '<circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 7v5M5 17v-2.5h14V17M12 12v2.5"/>',
  ops: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
  hr: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 11h5M18.5 8.5v5"/>',
  ipo: '<path d="M4 20h16M6 16v-4M10 16V9M14 16v-6M18 16V5"/><path d="m5 9 5-4 4 3 5-5"/>',
  quality: '<path d="M12 3 4 6v6c0 4.5 3.4 8 8 9 4.6-1 8-4.5 8-9V6z"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
  academy: '<path d="m2 9 10-5 10 5-10 5z"/><path d="M6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5M22 9v6"/>',
  experts: '<circle cx="8" cy="8" r="3"/><circle cx="16" cy="8" r="3"/><path d="M2 20c0-3.3 2.7-6 6-6 1.5 0 2.9.6 4 1.5A6 6 0 0 1 22 20"/>'
};
function svcGrid() {
  const ic = k => `<svg viewBox="0 0 24 24" aria-hidden="true">${SVC_IC[k] || SVC_IC.ops}</svg>`;
  const tiles = [
    ...C.solutions.map(s => ({ k: s.id, n: T(s.name), d: T(s.d), go: 'giai-phap', sol: s.id })),
    { k: 'quality', n: t('Quản lý chất lượng bệnh viện', 'Hospital quality management'), d: t('Lộ trình đạt chuẩn JCI, AACI: đánh giá khoảng cách, chính sách, quy trình, đánh giá thử và chuyển giao.', 'Roadmaps to JCI and AACI: gap assessment, policies, procedures, mock surveys and hand-over.'), go: 'du-an' },
    { k: 'academy', n: t('Học viện & Đào tạo', 'Academy & training'), d: t('Trung tâm đào tạo nội bộ, Smart LMS, giảng viên nội bộ và chứng chỉ Health Coach.', 'In-house training centres, Smart LMS, internal trainers and Health Coach certification.'), go: 'hoc-vien' },
    { k: 'experts', n: t('Đội ngũ chuyên gia đồng hành', 'Experts alongside you'), d: t('Hơn 30 chuyên gia từng điều hành thực tế, làm việc tại chỗ và từ xa theo từng dự án.', '30+ experts who have run organisations, working on-site and remotely on each project.'), go: 'chuyen-gia' }
  ];
  return `<div class="svc">${tiles.map(x => `<button class="svt" data-go="${x.go}"${x.sol ? ` data-sol="${esc(x.sol)}"` : ''}><span class="ic">${ic(x.k)}</span><h3>${esc(x.n)}</h3><p>${esc(x.d)}</p></button>`).join('')}</div>`;
}
V['trang-chu'] = () => {
  const h = C.site.hero, parts = T(h.title).split('|');
  const mos = (h.photos || []).map(exById).filter(e => e && e.photo && !e.hidden).slice(0, 6);
  const featured = vis(C.cases).filter(c => c.featured).slice(0, 6);
  const casesFor = ind => vis(C.cases).filter(c => c.industry === ind);
  const board = vis(C.experts).filter(e => (e.groups || []).includes('board')).slice(0, 3);
  return `
  <section class="hero"><div class="wrap"><div>
      <span class="eyebrow">${esc(T(h.eyebrow))}</span>
      <h1 style="margin-top:18px">${esc(parts[0])}${parts[1] ? `<i>${esc(parts[1])}</i>` : ''}</h1>
      <p class="slogan">${esc(h.slogan)}</p>
      <p class="lead">${esc(T(h.lead))}</p>
      <div class="cta"><button class="btn gold" data-go="lien-he">${ICON.cal} ${t('Đặt lịch trao đổi 30 phút', 'Book a 30-minute call')}</button><button class="btn ghost" data-go="du-an">${t('Xem dự án tiêu biểu', 'See our projects')} ${ICON.arrow}</button></div></div>
    <div class="mosaic">${mos.map(e => `<figure>${face(e)}<figcaption><b>${esc(T(e.name))}</b>${esc(T(e.role))}</figcaption></figure>`).join('')}</div></div>
    <div class="stats"><div class="wrap">${(C.site.stats || []).map(s => `<div class="stat"><b>${esc(s.v)}</b><span>${esc(T(s.l))}</span></div>`).join('')}<p class="stamp">${esc(T(C.site.statsNote))}</p></div></div></section>

  <section class="sec"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('LT&C làm gì', 'What we do')}</span><h2>${t('Ba nhóm khách hàng, <em class="g">một cách làm</em>: đi đến kết quả', 'Three client groups, <em class="g">one way of working</em>: results')}</h2></div>
      <p class="lead">${t('Chúng tôi chẩn đoán, thiết kế, cùng triển khai và chuyển giao năng lực cho đội ngũ của bạn, thay vì chỉ để lại một bản báo cáo.', 'We diagnose, design, implement with you and transfer capability to your team, instead of leaving behind a report.')}</p></div>
    <div class="what">${C.industries.map((i, k) => { const cs = casesFor(i.id); return `<div class="wcard"><span class="n">0${k + 1}</span><h3>${esc(T(i.name))}</h3><p>${esc(T(i.d))}</p>
      <ul class="ticks">${(T(i.points) || []).map(p => `<li>${esc(p)}</li>`).join('')}</ul>
      <div class="proof">${cs.length ? `<b>${t('Dự án', 'Projects')}</b><span>${cs.slice(0, 3).map(c => esc(T(c.client))).join(' · ')}</span>` : ''}<button class="link" data-go="${cs.length ? 'du-an' : 'giai-phap'}" data-caseind="${esc(i.id)}" style="font-size:14px">${cs.length ? t('Xem dự án', 'View projects') : t('Xem giải pháp', 'View solutions')} ${ICON.arrow}</button></div></div>`; }).join('')}</div>
  </div></section>

  ${featured.length ? `<section class="sec band"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Dự án tiêu biểu', 'Featured projects')}</span><h2>${t('Chất lượng & vận hành theo <em class="g">chuẩn quốc tế</em>', 'Quality and operations to <em class="g">international standards</em>')}</h2></div>
      <p class="lead">${t('JCI, AACI, khung quản trị vận hành: cố vấn y khoa và chuyên gia vận hành của LT&C đồng hành từ đánh giá khoảng cách đến khi đội ngũ nội bộ tự vận hành hệ thống.', 'JCI, AACI and operating frameworks: LT&C medical advisors and operations experts stay from gap assessment until the internal team runs the system on its own.')}</p></div>
    <div class="cases">${featured.map(caseCard).join('')}</div>
    <div class="more-row"><button class="btn gold" data-go="du-an">${t('Tất cả dự án', 'All projects')} ${ICON.arrow}</button></div></div></section>` : ''}

  <section class="sec"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Dịch vụ chủ lực · Phương pháp 4D', 'Core services · The 4D approach')}</span><h2>${t('Mỗi dịch vụ lấp <em class="g">một khoảng trống cụ thể</em>', 'Each service closes <em class="g">a specific gap</em>')}</h2></div>
      <p class="lead">${t('Hơn 80% mục tiêu của tổ chức không đạt được do khó khăn khi thực thi. Vì vậy mọi giải pháp của LT&C đều đi qua 4 bước: Chẩn đoán, Thiết kế, Triển khai, Tạo kết quả.', 'More than 80% of organisational goals fail in execution. So every LT&C solution runs through four steps: Diagnose, Design, Deploy, Drive results.')}</p></div>
    ${svcGrid()}
    <div class="more-row"><button class="link" data-go="giai-phap">${t('Tìm giải pháp phù hợp với tổ chức của bạn', 'Find the right solution for you')} ${ICON.arrow}</button><button class="link" data-go="tu-danh-gia">${t('Làm bài tự đánh giá Smart Review 360', 'Take the Smart Review 360 self-assessment')} ${ICON.arrow}</button></div>
  </div></section>

  <section class="sec surface"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">The Change Catalyst · ${C.domains.length} ${t('lĩnh vực chuyên môn', 'practice areas')}</span><h2>${t('Mỗi lĩnh vực có <em class="g">chuyên gia phụ trách</em>', 'Every area has <em class="g">experts in charge</em>')}</h2></div>
      <p class="lead">${t('Vòng ngoài là các lĩnh vực chuyên môn, vòng trong là vai trò của LT&C trong từng giai đoạn thay đổi. Chọn một mảng để xem dịch vụ và chuyên gia.', 'The outer ring shows practice areas; the inner ring shows LT&C’s role at each stage of change. Select a segment.')}</p></div>
    ${catalyst()}</div></section>

  <section class="sec band"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Hội đồng cố vấn', 'Advisory board')}</span><h2>${t('Những người từng điều hành, nay đồng hành cùng bạn', 'Leaders who have run it, now working alongside you')}</h2></div>
      <p class="lead">${t('Cựu lãnh đạo BMW, Bosch, VinFast, Biomin cùng giảng viên AIT và chuyên gia y khoa quốc tế.', 'Former leaders of BMW, Bosch, VinFast and Biomin, with AIT faculty and international medical experts.')}</p></div>
    <div class="board">${board.map(e => `<button class="adv" data-ex="${esc(e.id)}">${e.photo ? `<img src="${esc(e.photo)}" alt="${esc(T(e.name))}">` : ''}<div><span class="eyebrow">${esc(T(e.role))}</span><h4>${esc(T(e.name))}</h4><p class="muted">${esc(T(e.bio))}</p></div></button>`).join('')}</div>
    <div class="facerow">${vis(C.experts).filter(e => !board.includes(e) && e.photo).slice(0, 14).map(e => `<button class="f" data-ex="${esc(e.id)}" title="${esc(T(e.name))}">${face(e)}</button>`).join('')}<button class="btn gold" data-go="chuyen-gia" style="margin-left:8px">${t('Xem 30+ chuyên gia', 'Meet 30+ experts')} ${ICON.arrow}</button></div>
  </div></section>

  <section class="sec surface"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Khách hàng & đối tác', 'Clients & partners')}</span><h2>${t('Được tin tưởng bởi bệnh viện và doanh nghiệp hàng đầu', 'Trusted by leading hospitals and companies')}</h2></div>
      <p class="lead">${t('Các tổ chức mà chuyên gia LT&C đã thực hiện dự án tư vấn, chuyển đổi và phát triển năng lực.', 'Organisations where LT&C experts have delivered advisory, transformation and capability projects.')}</p></div>
    ${logoWall()}<div class="more-row"><button class="link" data-go="khach-hang">${t('Xem toàn bộ khách hàng & đối tác', 'See all clients & partners')} ${ICON.arrow}</button></div></div></section>

  ${sortedNews().length ? `<section class="sec"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Tin tức & Báo chí', 'News & press')}</span><h2>${t('Hoạt động mới nhất', 'Latest from LT&C')}</h2></div><p class="lead">${t('Sự kiện, dự án, báo chí và góc nhìn chuyên gia.', 'Events, projects, press and expert insights.')}</p></div>
    <div class="news">${sortedNews().slice(0, 3).map(newsCard).join('')}</div>
    <div class="more-row"><button class="link" data-go="tin-tuc">${t('Tất cả tin tức', 'All news')} ${ICON.arrow}</button></div></div></section>` : ''}
  ${ctaEnd()}`;
};

V['du-an'] = () => {
  const list = vis(C.cases).filter(c => state.caseInd === 'all' || c.industry === state.caseInd);
  const F = [['all', t('Tất cả', 'All')], ...C.industries.map(i => [i.id, T(i.name)])];
  return `${pageHero(t('Dự án', 'Projects'), t('Dự án & <em class="g">case study</em>', 'Projects & <em class="g">case studies</em>'), t('Mỗi dự án được trình bày theo cùng một khung: bối cảnh, cách LT&C làm theo phương pháp 4D, kết quả và chuyên gia tham gia.', 'Each project follows the same frame: context, how LT&C worked through 4D, results and the experts involved.'))}
  <section class="sec tight"><div class="wrap">
    <div class="dots" role="group" style="margin-bottom:28px">${F.map(([k, n]) => `<button data-caseind2="${esc(k)}" aria-pressed="${state.caseInd === k}">${esc(n)}</button>`).join('')}</div>
    ${list.length ? `<div class="cases">${list.map(caseCard).join('')}</div>` : `<p class="muted">${t('Chưa có dự án trong nhóm này.', 'No projects in this group yet.')}</p>`}
  </div></section>${ctaEnd()}`;
};
function caseView(c) {
  const ind = C.industries.find(i => i.id === c.industry), a = c.approach || {}, res = (c.results || []).filter(r => r && r.v);
  const ex = visEx(c.experts), sols = (c.solutions || []).map(solById).filter(Boolean);
  return `<section class="phero"><div class="wrap"><p class="crumb"><button data-go="trang-chu">${t('Trang chủ', 'Home')}</button> / <button data-go="du-an">${t('Dự án', 'Projects')}</button></p>
    <div class="chdr">${c.logo ? `<div class="lgw"><img src="${esc(c.logo)}" alt="${esc(T(c.client))}"></div>` : ''}<div style="display:grid;gap:12px"><span class="eyebrow">${esc(T(c.client))}</span><h1 style="font-size:clamp(30px,4.4vw,50px)">${esc(T(c.title))}</h1>
    <div class="meta">${ind ? `<span><b>${t('Lĩnh vực', 'Sector')}:</b> ${esc(T(ind.name))}</span>` : ''}${c.location ? `<span><b>${t('Địa điểm', 'Location')}:</b> ${esc(c.location)}</span>` : ''}${c.period ? `<span><b>${t('Thời gian', 'Period')}:</b> ${esc(c.period)}</span>` : ''}${T(c.status) ? `<span><b>${t('Trạng thái', 'Status')}:</b> ${esc(T(c.status))}</span>` : ''}</div></div></div></div></section>
  <section class="sec"><div class="wrap" style="display:grid;gap:56px">
    <div class="duo" style="align-items:start"><div style="display:grid;gap:12px"><span class="lbl">${t('Bối cảnh', 'Context')}</span><p class="lead" style="color:var(--ink)">${esc(T(c.challenge) || t('Thông tin chi tiết về dự án đang được cập nhật.', 'Project details are being updated.'))}</p>
      ${sols.length ? `<div style="display:flex;gap:6px;flex-wrap:wrap">${sols.map(s => `<button class="pill" data-go="giai-phap" data-sol="${esc(s.id)}" style="border:0;cursor:pointer">${esc(T(s.name))}</button>`).join('')}</div>` : ''}</div>
      ${c.image ? `<div class="photo" style="aspect-ratio:4/3"><img src="${esc(c.image)}" alt=""></div>` : ''}</div>
    ${D4.some(([k]) => T(a[k])) ? `<div style="display:grid;gap:20px"><span class="lbl">${t('LT&C đã làm gì · Phương pháp 4D', 'What LT&C did · The 4D approach')}</span>
      <div class="steps">${D4.map(([k, en, vi], i) => `<div class="step"><span class="n">D${i + 1} · ${esc(T(vi))}</span><h4>${en}</h4><p>${esc(T(a[k]))}</p></div>`).join('')}</div></div>` : ''}
    ${(c.gallery || []).length ? `<div class="gal">${c.gallery.map(g => `<div class="photo"><img src="${esc(g)}" alt="" loading="lazy"></div>`).join('')}</div>` : ''}
    ${res.length ? `<div style="display:grid;gap:20px"><span class="lbl">${t('Kết quả', 'Results')}</span><div class="metrics">${res.map(r => `<div class="metric"><b>${esc(r.v)}</b><span>${esc(T(r.l))}</span></div>`).join('')}</div></div>` : ''}
    ${T(c.quote) ? `<blockquote class="quote" style="margin:0">“${esc(T(c.quote))}”${c.quoteBy ? `<small>${esc(c.quoteBy)}</small>` : ''}</blockquote>` : ''}
    ${vis(C.news).some(n => n.case === c.id) ? `<div style="display:grid;gap:16px"><span class="lbl">${t('Báo chí & tin tức về dự án', 'Press & news about this project')}</span><div class="news">${vis(C.news).filter(n => n.case === c.id).map(newsCard).join('')}</div></div>` : ''}
    ${ex.length ? `<div style="display:grid;gap:16px"><span class="lbl">${t('Chuyên gia tham gia', 'Experts involved')}</span><div class="people">${ex.map(e => ppBtn(e)).join('')}</div></div>` : ''}
    <div><button class="link" data-go="du-an">← ${t('Tất cả dự án', 'All projects')}</button></div>
  </div></section>${ctaEnd()}`;
}

V['khach-hang'] = () => {
  const groups = [['health', t('Y tế – Bệnh viện, phòng khám', 'Healthcare – hospitals and clinics')], ['biz', t('Doanh nghiệp – Sản xuất, thương mại, dịch vụ, tài chính', 'Businesses – manufacturing, trading, services, finance')], ['eco', t('Đối tác hệ sinh thái', 'Ecosystem partners')]];
  const list = g => vis(C.logos).filter(l => l.group === g);
  const cs = vis(C.cases);
  return `${pageHero(t('Khách hàng & Đối tác', 'Clients & partners'), t('Khách hàng & <em class="g">đối tác</em>', 'Clients & <em class="g">partners</em>'), t('Các bệnh viện, tập đoàn và doanh nghiệp mà chuyên gia LT&C đã thực hiện dự án tư vấn, chuyển đổi và phát triển năng lực, cùng mạng lưới đối tác giúp LT&C cung cấp giải pháp trọn gói.', 'Hospitals, corporations and companies where LT&C experts have delivered advisory, transformation and capability projects, and the partner network behind our integrated solutions.'))}
  <section class="sec tight"><div class="wrap" style="display:grid;gap:56px">
    ${cs.length ? `<div style="display:grid;gap:18px"><div class="head split" style="margin:0"><div><span class="eyebrow">${t('Dự án tiêu biểu', 'Featured projects')}</span><h2 style="font-size:clamp(26px,3vw,34px)">${t('Khách hàng đang đồng hành cùng LT&C', 'Clients working with LT&C')}</h2></div></div>
      <div class="logos">${cs.filter(c => c.logo && !c.logo.startsWith('img/ltc-')).map(c => `<div title="${esc(T(c.client))}" data-go="${esc('du-an-' + c.id)}" style="cursor:pointer"><img src="${esc(c.logo)}" alt="${esc(T(c.client))}" style="filter:none;opacity:1"></div>`).join('')}</div></div>` : ''}
    ${groups.map(([g, n]) => list(g).length ? `<div style="display:grid;gap:18px"><div style="display:flex;align-items:baseline;gap:14px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding-bottom:12px"><h2 style="font-size:clamp(24px,2.8vw,32px)">${esc(n)}</h2><span class="pill">${list(g).length}</span></div>
      <div class="logos">${list(g).map(l => `<div title="${esc(l.name)}"><img src="${esc(l.src)}" alt="${esc(l.name)}" loading="lazy" style="filter:none;opacity:1"></div>`).join('')}</div></div>` : '').join('')}
    <p class="note">${t('Danh sách theo hồ sơ năng lực LT&C, cập nhật 10/2026.', 'Based on the LT&C company profile, October 2026.')}</p>
  </div></section>${ctaEnd()}`;
};

V['giai-phap'] = () => `
  ${pageHero(t('Giải pháp', 'Solutions'), t('Sáu giải pháp, <em class="g">một lời hứa</em>: đi đến kết quả', 'Six solutions, <em class="g">one promise</em>: results'), t('Bắt đầu từ bài toán của bạn, sau đó xem cách LT&C làm, kết quả bàn giao và chuyên gia phụ trách từng giải pháp.', 'Start from your challenge, then see how LT&C works, what we deliver and who leads each solution.'))}
  <section class="sec tight"><div class="wrap">${picker()}</div></section>
  <section class="sec band"><div class="wrap gaps">
    <div><span class="eyebrow">${t('Vì sao chiến lược không thành kết quả', 'Why strategy fails to deliver')}</span><div class="big80" style="margin-top:18px">80<sup>%</sup></div>
      <p class="lead" style="margin-top:18px">${t('Nghiên cứu cho thấy hơn 80% mục tiêu của tổ chức không đạt được chủ yếu do khó khăn khi thực thi, không phải do bản thân chiến lược.', 'Research indicates that more than 80% of organisational goals are missed mainly because of execution, not strategy.')}</p></div>
    <div class="gaplist">${GAPS.map(g => `<div><b>${esc(T(g.k))}</b><div><h4>${esc(T(g.name))}</h4><p class="muted">${esc(T(g.d))}</p></div></div>`).join('')}</div></div></section>
  <section class="sec tight"><div class="wrap">
    ${C.solutions.map(s => { const cs = vis(C.cases).filter(c => (c.solutions || []).includes(s.id)); return `<div class="sd" id="sol-${esc(s.id)}"><div><div class="n">${esc(s.n)}</div></div><div>
      <h2>${esc(T(s.name))}</h2><p class="tag">${esc(T(s.tag))}</p><p class="lead" style="margin-top:12px">${esc(T(s.d))}</p>
      <div class="cols"><div><h4>${t('Vấn đề thường gặp', 'The problem')}</h4><p>${esc(T(s.prob))}</p></div><div><h4>${t('LT&C làm gì', 'What LT&C does')}</h4><p>${esc(T(s.how))}</p></div><div><h4>${t('Bàn giao', 'Deliverables')}</h4><p>${esc(T(s.out))}</p></div></div>
      <div style="margin-top:22px;display:grid;gap:10px"><span class="lbl">${t('Chuyên gia liên quan', 'Related experts')}</span><div class="people">${visEx([...new Set((s.dom || []).flatMap(d => (domById(d) || {}).ex || []))]).slice(0, 5).map(e => ppBtn(e)).join('')}</div></div>
      ${cs.length ? `<div style="margin-top:16px;display:flex;gap:8px 16px;flex-wrap:wrap;align-items:center"><span class="lbl">${t('Dự án', 'Projects')}</span>${cs.map(c => `<button class="link" data-go="${esc('du-an-' + c.id)}">${esc(T(c.client))}</button>`).join('')}</div>` : ''}
    </div></div>`; }).join('')}</div></section>
  <section class="sec surface"><div class="wrap"><div class="head"><span class="eyebrow">${t('Phương pháp 4D', 'The 4D approach')}</span><h2>${t('Cách LT&C triển khai mọi dự án', 'How LT&C runs every engagement')}</h2></div>${fourD()}</div></section>
  <section class="sec"><div class="wrap duo" style="align-items:start"><div style="display:grid;gap:14px"><span class="eyebrow">${t('Mô hình đồng hành', 'Engagement model')}</span><h2>${t('Chọn mức độ đồng hành phù hợp', 'Choose how closely we work together')}</h2>
      <p class="lead">${t('Từ khuyến nghị chiến lược đến đối tác đồng đầu tư. Càng xuống sâu, LT&C càng gắn trách nhiệm với kết quả.', 'From strategic recommendations to co-investment. The deeper the level, the more LT&C shares accountability for results.')}</p></div>${ladder()}</div></section>
  ${ctaEnd()}`;

V['linh-vuc'] = () => `
  ${pageHero(t('Lĩnh vực chuyên môn', 'Practice areas'), 'The Change Catalyst', t('Các lĩnh vực chuyên môn ở vòng ngoài, vai trò xúc tác ở vòng trong. Mỗi lĩnh vực có nhóm chuyên gia phụ trách, phối hợp theo từng dự án.', 'Practice areas on the outer ring, catalyst roles on the inner ring. Each area has its own expert group.'))}
  <section class="sec surface"><div class="wrap">${catalyst()}</div></section>
  <section class="sec"><div class="wrap"><div class="dl">${C.domains.map((d, k) => `<div class="dom"><div class="top"><span class="eyebrow">${String(k + 1).padStart(2, '0')} · ${esc(T(d.verb))}</span><span class="pill">${visEx(d.ex).length} ${t('chuyên gia', 'experts')}</span></div>
      <h3>${esc(T(d.name))}</h3><p class="muted" style="font-size:15px">${esc(T(d.d))}</p><ul class="ticks">${(T(d.s) || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul>
      <div class="people">${visEx(d.ex).map(e => ppBtn(e, false)).join('')}</div></div>`).join('')}</div></div></section>
  ${ctaEnd()}`;

const EXG = [['board', () => t('Hội đồng cố vấn', 'Advisory board')], ['core', () => t('Đội ngũ lõi', 'Core team')], ['health', () => t('Chuyên gia Y tế', 'Healthcare experts')], ['net', () => t('Mạng lưới chuyên gia', 'Expert network')]];
V['chuyen-gia'] = () => {
  const F = [['all', t('Tất cả', 'All')], ['board', t('Hội đồng cố vấn', 'Advisory board')], ['core', t('Đội ngũ lõi', 'Core team')], ['health', t('Chuyên gia Y tế', 'Healthcare')], ...C.domains.map(d => [d.id, wl(d)])];
  const list = vis(C.experts).filter(e => state.exf === 'all' || (e.groups || []).includes(state.exf) || (e.dom || []).includes(state.exf));
  return `${pageHero(t('Chuyên gia', 'Experts'), t('Mạng lưới chuyên gia <em class="g">là tài sản lớn nhất</em> của LT&C', 'Our expert network <em class="g">is our greatest asset</em>'), t('Hơn 20 chuyên gia tư vấn và chuyên môn, hơn 30 chuyên gia chuyên biệt và nhân sự dự án, làm việc kết hợp tại chỗ và từ xa.', '20+ consultants and subject matter experts, 30+ specialised consultants and project staff, working on-site and offshore.'))}
  <section class="sec tight"><div class="wrap">
    <div class="dots" role="group" style="margin-bottom:28px">${F.map(([k, n]) => `<button data-exf2="${esc(k)}" aria-pressed="${state.exf === k}">${esc(n)}</button>`).join('')}</div>
    <p class="muted" style="margin-bottom:20px;font-family:var(--f-label);letter-spacing:.06em">${list.length} ${t('chuyên gia', 'experts')}</p>
    ${state.exf === 'all' ? EXG.map(([g, n]) => { const xs = list.filter(e => (e.groups || [])[0] === g); return xs.length ? `<div class="exsec"><h2>${esc(n())}</h2><div class="exgrid">${xs.map(exCard).join('')}</div></div>` : ''; }).join('') : `<div class="exgrid">${list.map(exCard).join('')}</div>`}</div></section>${ctaEnd()}`;
};

V['hoc-vien'] = () => `
  ${pageHero(t('Học viện LT&C', 'LT&C Academy'), t('Từ đào tạo lẻ đến <em class="g">hệ thống học tập</em> của tổ chức', 'From one-off training to an <em class="g">organisational learning system</em>'), t('Thiết lập và vận hành trung tâm đào tạo, nền tảng Smart LMS, đội ngũ giảng viên nội bộ và các chương trình chứng chỉ.', 'Training centres, Smart LMS, internal trainers and certification programmes.'))}
  <section class="sec"><div class="wrap duo" style="align-items:start">
    <div style="display:grid;gap:14px"><span class="eyebrow">${t('Thiết lập & quản lý trung tâm đào tạo', 'Training centre set-up & management')}</span><h2>${t('Hệ thống đào tạo doanh nghiệp toàn diện', 'A comprehensive corporate training system')}</h2>
      <p class="lead">${t('Năm khối đào tạo bao phủ toàn bộ vòng đời nhân sự. Bàn giao gồm khung năng lực theo nhóm vị trí, lộ trình đào tạo, tài liệu chuẩn hóa, công cụ đánh giá và kho tri thức số trên Smart LMS.', 'Five blocks across the employee lifecycle. Deliverables: competency frameworks, roadmaps, standard materials, assessment tools and a digital knowledge base on Smart LMS.')}</p>
      <p style="font-family:var(--f-label);font-weight:600;letter-spacing:.06em;color:var(--blue)">${t('Tri thức → Năng lực → Hiệu suất → Tăng trưởng bền vững', 'Knowledge → Capability → Performance → Sustainable Growth')}</p></div>
    <div class="ladder">${[[t('Định hướng, hội nhập & văn hóa', 'Orientation, onboarding & culture'), t('Định hướng, hội nhập, văn hóa doanh nghiệp', 'Orientation, onboarding, culture')], [t('Năng lực cốt lõi cho nhân viên', 'Core competencies'), t('Chính sách, quy trình cơ bản, kỹ năng mềm', 'Policies, basic processes, soft skills')], [t('Năng lực lãnh đạo & quản lý', 'Leadership & management'), t('Lãnh đạo cấp cao; quản lý cấp trung', 'Executive and middle management')], [t('Chuyên môn ngành & nghề', 'Industry & professional expertise'), t('Chuyên môn quản lý, chuyên ngành, theo vị trí', 'Management, industry and job-specific')], [t('Phát triển cá nhân', 'Personal development'), t('Gia đình, nuôi dạy con, ngoại ngữ, phát triển bản thân', 'Family, parenting, languages, growth')]].map((r, k) => `<div class="rung" style="grid-template-columns:auto minmax(0,1fr)"><span class="mid" style="justify-self:start">${k + 1}</span><div><b>${r[0]}</b><br><span class="muted" style="font-size:14.5px">${r[1]}</span></div></div>`).join('')}</div></div></section>
  <section class="sec band"><div class="wrap duo">
    <div class="pgrid" style="aspect-ratio:5/4"><div class="photo"><img src="img/photos/017-006.jpg" alt="${t('Chứng chỉ Health Coach', 'Health Coach certificate')}" loading="lazy"></div><div class="photo"><img src="img/photos/017-007.jpg" alt="" loading="lazy"></div><div class="photo"><img src="img/photos/017-008.jpg" alt="" loading="lazy"></div></div>
    <div style="display:grid;gap:14px"><span class="eyebrow">${t('Chương trình chứng chỉ', 'Certification')}</span><h2>Health Coach Certification</h2>
      <p class="lead">${t('Đào tạo và cấp chứng chỉ Health Coach cho đội ngũ chăm sóc sức khỏe, tư vấn dinh dưỡng và lối sống trong bệnh viện, phòng khám và doanh nghiệp.', 'Health Coach training and certification for health, nutrition and lifestyle teams.')}</p>
      <div><button class="btn gold" data-go="lien-he">${t('Đăng ký lớp gần nhất', 'Register for the next class')} ${ICON.arrow}</button></div></div></div></section>
  <section class="sec"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Giảng viên nội bộ & giảng viên mời', 'Internal & guest trainers')}</span><h2>${t('Đào tạo người đào tạo', 'Train the trainer')}</h2></div>
      <p class="lead">${t('Chương trình gắn với quy trình riêng cần giảng viên nội bộ; LT&C huấn luyện họ và thiết lập cơ chế ghi nhận. Chuyên gia trong nước và quốc tế được mời cho các mô-đun chuyên sâu, nội dung được số hóa để tái sử dụng.', 'Company-specific programmes need internal trainers; LT&C trains them and sets up recognition. Guest experts deliver specialist modules, digitised for reuse.')}</p></div>
    <div class="pgrid"><div class="photo"><img src="img/photos/004-005.jpg" alt="" loading="lazy"></div><div class="photo"><img src="img/photos/004-003.jpg" alt="" loading="lazy"></div><div class="photo"><img src="img/photos/004-002.jpg" alt="" loading="lazy"></div></div></div></section>
  <section class="sec surface"><div class="wrap">
    <div class="head split"><div><span class="eyebrow">${t('Hệ sinh thái LT&C', 'The LT&C ecosystem')}</span><h2>${t('Chương trình cho cá nhân và gia đình', 'Programmes for individuals and families')}</h2></div>
      <p class="lead">${t('Từ năm 2015, LT&C khởi đầu bằng đào tạo và huấn luyện cuộc sống với thông điệp "Nâng cao kỹ năng – Cải thiện cuộc sống".', 'Since 2015, LT&C began with life training and coaching under the motto “Enhance skills, improve life”.')}</p></div>
    <div class="cards3">
      <div class="card"><span class="n">${t('Người lớn', 'Adults')}</span><h3>${t('Phát triển năng lực cá nhân', 'Personal capability')}</h3><ul class="ticks"><li>${t('Kết nối bản thân – Làm chủ cuộc sống', 'Connect with yourself, master your life')}</li><li>${t('Tương tác – Cải thiện mối quan hệ', 'Better relationships')}</li><li>Map For Life</li></ul></div>
      <div class="card"><span class="n">${t('Phụ huynh', 'Parents')}</span><h3>${t('Phụ huynh thay đổi – Con cái hạnh phúc', 'Parents change, children thrive')}</h3><p>${t('Khai vấn 1:1 giúp cha mẹ làm chủ cảm xúc, giao tiếp và đồng hành cùng con.', '1:1 coaching for parents on emotions, communication and supporting their child.')}</p></div>
      <div class="card"><span class="n">3T Kids Academy</span><h3>${t('Học viện khai phóng cho thanh thiếu niên', 'Liberal academy for young people')}</h3><p>${t('Giá trị 3T: Thông thái, Thịnh vượng, Thiện tâm. Bốn trụ cột: Học để biết, để làm, để chung sống, để trưởng thành.', '3T values: Wisdom, Wealth, Willing. Learning to know, to do, to live together and to grow.')}</p></div></div></div></section>
  ${ctaEnd()}`;

V['tin-tuc'] = () => {
  const all = sortedNews(), types = Object.keys(NEWS_TYPES).filter(k => all.some(n => n.type === k));
  const list = all.filter(n => state.newsType === 'all' || n.type === state.newsType);
  return `${pageHero(t('Tin tức', 'News'), t('Tin tức, <em class="g">báo chí</em> & góc nhìn', 'News, <em class="g">press</em> & insights'), '')}
  <section class="sec tight"><div class="wrap">
    <div class="tabs" role="group">${[['all', t('Tất cả', 'All')], ...types.map(k => [k, T(NEWS_TYPES[k])])].map(([k, n]) => `<button data-nt="${k}" aria-pressed="${state.newsType === k}">${esc(n)}</button>`).join('')}</div>
    <div class="news" style="margin-top:12px">${list.map(newsCard).join('')}</div></div></section>
  <section class="sec band"><div class="wrap cta-end">
    <div style="display:grid;gap:14px"><span class="eyebrow">LT&C Leader Brief</span><h2>${t('Một chủ đề, hai tháng một kỳ, <em class="g">viết cho người ra quyết định</em>', 'One topic, every two months, <em class="g">for decision-makers</em>')}</h2>
      <p class="lead">${t('Dành cho CEO, Hội đồng quản trị và giám đốc bệnh viện.', 'For CEOs, boards and hospital directors.')}</p></div>
    <form class="form" id="fBrief" novalidate><div class="hp" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
      <div class="fld"><label for="fBrief-name">${t('Họ và tên', 'Full name')} *</label><input id="fBrief-name" name="name" required></div>
      <div class="fld"><label for="fBrief-role">${t('Chức danh', 'Job title')}</label><input id="fBrief-role" name="role"></div>
      <div class="fld"><label for="fBrief-org">${t('Tổ chức', 'Organisation')} *</label><input id="fBrief-org" name="org" required></div>
      <div class="fld"><label for="fBrief-email">Email *</label><input id="fBrief-email" name="email" type="email" required></div>
      <div class="full"><button class="btn gold" type="submit">${t('Đăng ký nhận bản tin', 'Subscribe')} ${ICON.arrow}</button></div></form></div></section>`;
};
function newsView(n) {
  return `${pageHero(`<button data-go="tin-tuc">${t('Tin tức', 'News')}</button>`, esc(T(n.title)), `${esc(T(NEWS_TYPES[n.type] || NEWS_TYPES.news))}${n.date ? ' · ' + fmtDate(n.date) : ''}${n.source ? ' · ' + esc(n.source) : ''}`)}
  <section class="sec"><div class="wrap" style="max-width:820px;display:grid;gap:22px">${n.image ? `<figure style="margin:0;display:grid;gap:8px"><div class="photo"><img src="${esc(n.image)}" alt="${esc(T(n.title))}"></div>${n.credit ? `<figcaption class="note" style="margin:0">${esc(n.credit)}</figcaption>` : ''}</figure>` : ''}
    <p class="lead" style="color:var(--ink)">${esc(T(n.excerpt))}</p>${T(n.body).split(/\n{2,}/).filter(Boolean).map(p => `<p>${esc(p)}</p>`).join('')}
    ${safeUrl(n.url) ? `<a class="link" href="${esc(n.url)}" target="_blank" rel="noopener">${t('Xem bài gốc', 'Original article')}${n.source ? ' · ' + esc(n.source) : ''} ${ICON.ext}</a>` : ''}
    ${n.case && caseById(n.case) && !caseById(n.case).hidden ? `<div class="card" style="grid-template-columns:auto minmax(0,1fr);align-items:center;gap:16px">${caseById(n.case).logo ? `<img src="${esc(caseById(n.case).logo)}" alt="" style="width:64px;height:64px;object-fit:contain;background:#fff;border-radius:8px;padding:4px">` : '<span></span>'}<div style="display:grid;gap:4px"><span class="lbl">${t('Dự án liên quan', 'Related project')}</span><button class="link" data-go="${esc('du-an-' + n.case)}">${esc(T(caseById(n.case).client))}: ${esc(T(caseById(n.case).title))} ${ICON.arrow}</button></div></div>` : ''}
    <div><button class="link" data-go="tin-tuc">← ${t('Tất cả tin tức', 'All news')}</button></div></div></section>`;
}

V['ve-ltc'] = () => `
  ${pageHero(t('Về LT&C', 'About LT&C'), t('Hơn một công ty tư vấn: <em class="g">đối tác chuyển đổi</em> định hướng thực thi', 'More than a consulting firm: an <em class="g">execution-driven</em> transformation partner'), '“Partner with Experts – Break Through All Boundaries”')}
  <section class="sec"><div class="wrap duo"><div style="display:grid;gap:16px"><span class="eyebrow">${t('Chúng tôi là ai', 'Who we are')}</span>
      <p class="lead" style="color:var(--ink)">${t('Thành lập năm 2015, LT&C là công ty tư vấn quản lý và phát triển năng lực, quy tụ mạng lưới chuyên gia ngành và lãnh đạo cấp cao có nền tảng học thuật sâu và kinh nghiệm điều hành thực tế tại các tổ chức hàng đầu trong nước và quốc tế.', 'Founded in 2015, LT&C is a management consulting and capability development firm bringing together industry experts and senior executives with strong academic backgrounds and hands-on leadership experience.')}</p>
      <p class="muted">${t('LT&C kết hợp tư duy chiến lược, triển khai thực tế và hiểu biết sâu về thị trường Việt Nam để giúp tổ chức đạt chuẩn quốc tế và sẵn sàng IPO.', 'LT&C combines strategic thinking, practical execution and local insight to help organisations reach international standards and IPO readiness.')}</p>
      <p style="font-family:var(--f-label);font-weight:600;letter-spacing:.06em;color:var(--blue)">${t('Chiến lược → Thực thi → Lợi thế cạnh tranh', 'Strategy → Execution → Competitive Advantage')}</p></div>
    <div class="photo" style="aspect-ratio:4/3"><img src="img/photos/004-005.jpg" alt="" loading="lazy"></div></div></section>
  <section class="sec surface"><div class="wrap"><div class="cards3">
    <div class="card"><span class="n">${t('Tầm nhìn', 'Vision')}</span><p style="color:var(--ink);font-family:var(--f-display);font-size:20px;line-height:1.4">${t('Trở thành đối tác chuyển đổi được tin chọn, giúp tổ chức nâng tầm quản trị, tăng hiệu suất, tạo giá trị bền vững và thích ứng linh hoạt.', 'To be the trusted transformation partner of choice, helping organisations elevate governance, performance and sustainable value.')}</p></div>
    <div class="card"><span class="n">${t('Sứ mệnh', 'Mission')}</span><p style="color:var(--ink);font-family:var(--f-display);font-size:20px;line-height:1.4">${t('Phục vụ và tạo giá trị thực chất qua các sáng kiến chuyển đổi lấy con người làm trung tâm.', 'To create meaningful value through people-centred transformation.')}</p><p>${t('Thành công được đo bằng kết quả kinh doanh hữu hình.', 'Success is measured by tangible business outcomes.')}</p></div>
    <div class="card"><span class="n">${t('Giá trị cốt lõi', 'Core values')}</span><div style="display:grid;gap:10px">${[['Patriotic', t('Tinh thần yêu nước', 'Love of country')], ['Wisdom', t('Trí tuệ', 'Wisdom')], ['Vision', t('Tầm nhìn', 'Vision')]].map(v => `<div><b style="font-family:var(--f-display);font-size:22px;font-weight:500">${v[0]}</b> <span class="muted">· ${v[1]}</span></div>`).join('')}</div></div></div></div></section>
  <section class="sec"><div class="wrap"><div class="head split"><div><span class="eyebrow">${t('Đối tác hệ sinh thái', 'Ecosystem partners')}</span><h2>${t('Một mạng lưới, giải pháp trọn gói', 'One network, integrated solutions')}</h2></div>
    <p class="lead">${t('Pháp lý & tuân thủ · Săn đầu người · Coaching lãnh đạo · Nền tảng học tập số · ESG · Chứng nhận ISO · Thương mại hóa & phân phối · R&D.', 'Legal · Executive search · Leadership coaching · Digital learning · ESG · ISO certification · Commercialisation · R&D.')}</p></div>${logoWall(['eco'])}</div></section>
  ${ctaEnd()}`;

V['lien-he'] = () => `
  ${pageHero(t('Liên hệ', 'Contact'), t('Thay đổi bắt đầu từ <em class="g">một cuộc trò chuyện</em>', 'Change starts with <em class="g">a conversation</em>'), t('Để lại thông tin, chuyên gia LT&C sẽ liên hệ trong vòng 24 giờ làm việc để đặt lịch trao đổi 30 phút, không tính phí.', 'Leave your details and an LT&C consultant will contact you within 24 business hours.'))}
  <section class="sec"><div class="wrap cta-end"><div class="band" style="border-radius:16px;padding:32px;display:grid;gap:8px;align-content:start"><span class="eyebrow">LT&C</span><h3>${esc(T(C.site.contact.company))}</h3>${contactLines()}</div>
    <div>${contactForm('fContact', false)}</div></div></section>`;

const SCALE = [[1, 'Hoàn toàn chưa đúng', 'Not at all true'], [2, 'Ít đúng', 'Rarely true'], [3, 'Đúng một phần', 'Partly true'], [4, 'Phần lớn đúng', 'Mostly true'], [5, 'Hoàn toàn đúng', 'Fully true']];
function scores() { const r = {}; GAPS.forEach(g => { const ans = QUIZ.map((q, k) => q[0] === g.id ? state.q[k] : null).filter(Boolean); r[g.id] = ans.length ? Math.round((ans.reduce((a, b) => a + b, 0) - ans.length) / (ans.length * 4) * 100) : null; }); return r; }
const lvl = v => v == null ? ['—', 'var(--ink-3)'] : v < 40 ? [t('Cần ưu tiên', 'Priority'), 'var(--crit)'] : v < 70 ? [t('Đang hình thành', 'Developing'), 'var(--warn)'] : [t('Vững', 'Solid'), 'var(--ok)'];
function quizSide() {
  const s = scores();
  return `<div class="card side" id="qside"><span class="n">${t('Kết quả tạm tính', 'Live score')}</span>${GAPS.map(g => { const v = s[g.id], [ln, c] = lvl(v); return `<div class="bar"><div class="t"><span>${esc(T(g.name))}<span class="lvl" style="color:${c};background:color-mix(in srgb, ${c} 14%, transparent)">${ln}</span></span><b>${v == null ? '—' : v + '%'}</b></div><div class="tr"><i style="width:${v || 0}%;background:${c}"></i></div></div>`; }).join('')}
    <p class="muted" style="font-size:13.5px">${t('Dưới 40%: cần ưu tiên; 40–69%: đang hình thành; từ 70%: vững.', 'Below 40%: priority; 40–69%: developing; 70%+: solid.')}</p></div>`;
}
function quizMain() {
  if (state.qdone) {
    const s = scores(), weak = GAPS.slice().sort((a, b) => (s[a.id] ?? 101) - (s[b.id] ?? 101))[0], map = { a: ['smart-review', 'strategy'], b: ['od', 'hr'], c: ['ops', 'smart-review'] };
    return `<div class="qcard fade"><span class="eyebrow">${t('Kết quả sơ bộ', 'Preliminary result')}</span><h3 style="font-size:clamp(26px,3vw,34px)">${t('Khoảng trống cần ưu tiên', 'Gap to prioritise')}: <em class="g">${esc(T(weak.name))}</em></h3><p class="muted">${esc(T(weak.d))}</p>
      <div class="rec" style="grid-template-columns:1fr;border:0;padding:0"><div class="sols">${map[weak.id].map(solById).filter(Boolean).map(so => `<div class="sol"><span class="n">${t('Giải pháp gợi ý', 'Suggested solution')} ${esc(so.n)}</span><h4>${esc(T(so.name))}</h4><p class="muted" style="font-size:14px">${esc(T(so.tag))}</p></div>`).join('')}</div></div>
      <div style="border-top:1px solid var(--line);padding-top:20px;display:grid;gap:14px"><h4 style="font-family:var(--f-display);font-weight:500;font-size:21px">${t('Nhận báo cáo chi tiết và buổi trao đổi 30 phút', 'Get the detailed report and a 30-minute call')}</h4>${contactForm('fQuiz', true)}</div>
      <div><button class="link" id="qreset">${t('Làm lại bài đánh giá', 'Restart')}</button></div></div>`;
  }
  const k = state.qi, q = QUIZ[k], g = GAPS.find(x => x.id === q[0]), done = state.q.filter(Boolean).length;
  return `<div class="qcard"><div class="qmeta"><span>${esc(T(g.k))} · ${esc(T(g.name))}</span><span>${k + 1} / ${QUIZ.length}</span></div><div class="qprog"><i style="width:${done / QUIZ.length * 100}%"></i></div>
    <p class="qtext">${esc(L === 'en' ? q[2] : q[1])}</p><div class="scale" role="group">${SCALE.map(s => `<button data-sc="${s[0]}" aria-pressed="${state.q[k] === s[0]}"><b>${s[0]}</b><span>${L === 'en' ? s[2] : s[1]}</span></button>`).join('')}</div>
    <div class="qnav"><button class="btn ghost" id="qprev" ${k === 0 ? 'disabled style="opacity:.4"' : ''}>${t('Câu trước', 'Back')}</button>${done === QUIZ.length ? `<button class="btn gold" id="qfin">${t('Xem kết quả', 'See result')} ${ICON.arrow}</button>` : `<button class="btn ghost" id="qnext" ${!state.q[k] ? 'disabled style="opacity:.4"' : ''}>${t('Câu tiếp', 'Next')} ${ICON.arrow}</button>`}</div></div>`;
}
V['tu-danh-gia'] = () => `${pageHero('Smart Review 360', t('Tổ chức của bạn đang <em class="g">vướng ở đâu</em>?', 'Where is your organisation <em class="g">getting stuck</em>?'), t('15 câu hỏi, khoảng 10 phút, theo 3 khoảng trống Chiến lược – Thực thi, Năng lực và Tốc độ ra kết quả.', '15 questions, about 10 minutes, across three gaps.'))}
  <section class="sec"><div class="wrap quiz"><div id="qmain">${quizMain()}</div>${quizSide()}</div></section>`;
function bindQuiz() {
  const m = document.getElementById('qmain'); if (!m) return;
  const redraw = () => { m.innerHTML = quizMain(); document.getElementById('qside').outerHTML = quizSide(); bindQuiz(); };
  m.querySelectorAll('[data-sc]').forEach(b => b.onclick = () => { state.q[state.qi] = +b.dataset.sc; if (state.qi < QUIZ.length - 1) state.qi++; redraw(); });
  const p = document.getElementById('qprev'); if (p) p.onclick = () => { if (state.qi > 0) { state.qi--; redraw(); } };
  const n = document.getElementById('qnext'); if (n) n.onclick = () => { if (state.q[state.qi] && state.qi < QUIZ.length - 1) { state.qi++; redraw(); } };
  const f = document.getElementById('qfin'); if (f) f.onclick = () => { state.qdone = true; redraw(); };
  const r = document.getElementById('qreset'); if (r) r.onclick = () => { state.q = []; state.qi = 0; state.qdone = false; redraw(); };
  bindForm('fQuiz', 'smart-review-360', () => ({ scores: scores(), answers: state.q.slice() }));
}

/* ================== shell ================== */
const NAV = [['giai-phap', 'Giải pháp', 'Solutions'], ['du-an', 'Dự án', 'Projects'], ['khach-hang', 'Khách hàng', 'Clients'], ['linh-vuc', 'Lĩnh vực', 'Practice areas'], ['chuyen-gia', 'Chuyên gia', 'Experts'], ['hoc-vien', 'Học viện', 'Academy'], ['tin-tuc', 'Tin tức', 'News'], ['ve-ltc', 'Về LT&C', 'About'], ['lien-he', 'Liên hệ', 'Contact']];
function shell(cur) {
  const top = cur.startsWith('du-an') ? 'du-an' : cur.startsWith('tin-') ? 'tin-tuc' : cur;
  const links = NAV.map(([h, vi, en]) => `<a href="#${h}" ${h === top ? 'aria-current="page"' : ''}>${t(vi, en)}</a>`).join('');
  document.getElementById('nav').innerHTML = links;
  document.getElementById('nav2').innerHTML = links + `<a href="#tu-danh-gia" ${top === 'tu-danh-gia' ? 'aria-current="page"' : ''}>Smart Review 360</a>`;
  const cur2 = document.querySelector('#nav2 [aria-current]'); if (cur2) cur2.scrollIntoView({ block: 'nearest', inline: 'center' });
  document.getElementById('hdrCta').textContent = t('Đặt lịch trao đổi', 'Book a call');
  document.getElementById('lvi').setAttribute('aria-pressed', L === 'vi'); document.getElementById('len').setAttribute('aria-pressed', L === 'en');
  document.documentElement.lang = L;
  const c = C.site.contact, z = safeUrl((C.site.social || {}).zalo);
  document.getElementById('footer').innerHTML = `<div class="wrap">
    <div style="display:grid;gap:14px;align-content:start"><img src="img/ltc-logo-light.png" alt="LT&C" style="width:96px"><p style="font-family:var(--f-display);font-size:21px;color:var(--on-band);line-height:1.3">${esc(C.site.hero.slogan)}</p><p>${esc(T(c.company))}</p>${socialLinks()}</div>
    <div><h4>${t('Giải pháp', 'Solutions')}</h4><ul>${C.solutions.map(s => `<li><button class="fl" data-go="giai-phap" data-sol="${esc(s.id)}">${esc(T(s.name))}</button></li>`).join('')}</ul></div>
    <div><h4>LT&C</h4><ul>${NAV.slice(1).map(([h, vi, en]) => `<li><a href="#${h}">${t(vi, en)}</a></li>`).join('')}<li><a href="#tu-danh-gia">Smart Review 360</a></li></ul></div>
    <div><h4>${t('Liên hệ', 'Contact')}</h4><ul><li>${esc(T(c.address))}</li><li style="user-select:all">${esc(c.phone)}</li><li style="user-select:all">${esc(c.email)}</li></ul></div>
    <div class="legal"><span>© 2015–${new Date().getFullYear()} LT&C. ${t('Bảo lưu mọi quyền.', 'All rights reserved.')}</span><span>Strategy · Execution · Capability · <a href="admin/" style="opacity:.6">${t('Quản trị', 'Admin')}</a></span></div></div>`;
  document.getElementById('dock').innerHTML = `<div class="hot" id="hot" hidden><span class="muted">Hotline</span><b>${esc(c.phone)}</b><button class="copy" style="border-color:var(--line);color:var(--ink-2);justify-self:start" data-copy="${esc(c.phone)}">${t('Chép số', 'Copy number')}</button></div>
    ${z ? `<a class="db z" href="${esc(z)}" target="_blank" rel="noopener" aria-label="Zalo">Zalo</a>` : ''}
    <button class="db p" id="hotBtn" aria-label="Hotline" aria-expanded="false">${ICON.phone}</button>
    <button class="db c" data-go="lien-he" aria-label="${t('Đặt lịch trao đổi', 'Book a call')}">${ICON.cal}</button>`;
}
function route() {
  const h = location.hash.replace('#', '');
  if (h.startsWith('du-an-')) { const c = caseById(h.slice(6)); if (c && !c.hidden) return h; }
  if (h.startsWith('tin-') && h !== 'tin-tuc') { const n = newsById(h.slice(4)); if (n && !n.hidden) return h; }
  return V[h] ? h : 'trang-chu';
}
let pendingSol = null;
function render() {
  const cur = route();
  shell(cur);
  const v = document.getElementById('view');
  v.innerHTML = cur.startsWith('du-an-') ? caseView(caseById(cur.slice(6))) : (cur.startsWith('tin-') && cur !== 'tin-tuc') ? newsView(newsById(cur.slice(4))) : V[cur]();
  v.classList.remove('fade'); void v.offsetWidth; v.classList.add('fade');
  const base = (C.site.seo && C.site.seo.title) || 'LT&C';
  const nav = NAV.find(n => n[0] === cur);
  document.title = cur === 'trang-chu' ? base : `${nav ? nav[L === 'en' ? 2 : 1] : 'LT&C'} · LT&C`;
  bindPicker(); bindQuiz();
  bindForm('fEnd', 'contact-short'); bindForm('fContact', 'contact'); bindForm('fBrief', 'leader-brief');
  if (pendingSol) { const el = document.getElementById('sol-' + pendingSol); pendingSol = null; if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 30); }
}
function openEx(id) {
  const e = exById(id), m = document.getElementById('modal'); if (!e) return;
  const doms = (e.dom || []).map(domById).filter(Boolean), cs = vis(C.cases).filter(c => (c.experts || []).includes(id));
  m.innerHTML = `<div class="mbox" role="dialog" aria-modal="true" aria-labelledby="mxT"><button class="mx" id="mxC" aria-label="${t('Đóng', 'Close')}">×</button><div class="mp">${face(e)}</div>
    <div class="mc"><span class="eyebrow">${esc(T(e.role))}</span><h3 id="mxT">${esc(T(e.name))}</h3>${T(e.title) ? `<p class="ttl">${esc(T(e.title))}</p>` : ''}${exHl(e).length ? `<ul class="hl">${exHl(e).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : `<p class="muted">${esc(T(e.bio))}</p>`}
      ${doms.length ? `<div style="display:grid;gap:8px"><span class="lbl">${t('Lĩnh vực', 'Practice area')}</span>${doms.map(d => `<button class="link" data-go="linh-vuc" data-dom="${C.domains.indexOf(d)}">${esc(T(d.name))} ${ICON.arrow}</button>`).join('')}</div>` : ''}
      ${cs.length ? `<div style="display:grid;gap:8px"><span class="lbl">${t('Dự án', 'Projects')}</span>${cs.map(c => `<button class="link" data-go="${esc('du-an-' + c.id)}">${esc(T(c.client))} ${ICON.arrow}</button>`).join('')}</div>` : ''}
      <div><button class="btn gold" data-go="lien-he">${t('Đặt lịch trao đổi', 'Book a call')}</button></div></div></div>`;
  m.hidden = false; document.getElementById('mxC').focus();
}
const closeEx = () => { document.getElementById('modal').hidden = true; };

document.addEventListener('click', ev => {
  const el = ev.target.closest('[data-ex],[data-go],[data-dk],.seg,[data-lt],[data-exf2],[data-caseind2],[data-nt],[data-copy],#hotBtn,#mxC,#lvi,#len');
  if (!el) { if (ev.target === document.getElementById('modal')) closeEx(); return; }
  if (el.id === 'mxC') return closeEx();
  if (el.id === 'lvi' || el.id === 'len') { L = el.id === 'len' ? 'en' : 'vi'; try { localStorage.setItem('ltc-lang', L); } catch (e) {} return render(); }
  if (el.id === 'hotBtn') { const h = document.getElementById('hot'); h.hidden = !h.hidden; el.setAttribute('aria-expanded', !h.hidden); return; }
  if (el.dataset.copy) { const old = el.textContent; try { navigator.clipboard.writeText(el.dataset.copy).then(() => { el.textContent = t('Đã chép', 'Copied'); setTimeout(() => { el.textContent = old; }, 1400); }, () => {}); } catch (e) {} return; }
  if (el.dataset.ex && !el.dataset.go) return openEx(el.dataset.ex);
  if (el.classList.contains('seg')) return setDom(el.dataset.k);
  if (el.dataset.dk) return setDom(el.dataset.dk);
  if (el.dataset.lt) { state.logoTab = el.dataset.lt; const w = document.getElementById('lw'); const groups = [...w.querySelectorAll('[data-lt]')].map(b => b.dataset.lt); w.outerHTML = logoWall(groups); return; }
  if (el.dataset.exf2) { state.exf = el.dataset.exf2; return render(); }
  if (el.dataset.caseind2) { state.caseInd = el.dataset.caseind2; return render(); }
  if (el.dataset.nt) { state.newsType = el.dataset.nt; return render(); }
  if (el.dataset.go) {
    ev.preventDefault(); closeEx();
    if (el.dataset.exf) state.exf = el.dataset.exf;
    if (el.dataset.dom) state.dom = +el.dataset.dom;
    if (el.dataset.caseind) state.caseInd = el.dataset.caseind;
    if (el.dataset.sol) pendingSol = el.dataset.sol;
    go(el.dataset.go);
  }
});
document.addEventListener('keydown', ev => {
  if (ev.key === 'Escape') { closeEx(); const h = document.getElementById('hot'); if (h) h.hidden = true; }
  const s = ev.target.closest && ev.target.closest('.seg');
  if (s && (ev.key === 'Enter' || ev.key === ' ')) { ev.preventDefault(); setDom(s.dataset.k); }
});
window.addEventListener('hashchange', () => { render(); scrollTo(0, 0); });

(async function boot() {
  try { C = JSON.parse(document.getElementById('seed').textContent); } catch (e) { C = null; }
  try { const r = await fetch('content.json?v=' + Date.now(), { cache: 'no-store' }); if (r.ok) { const j = await r.json(); if (j && j.site) C = j; } } catch (e) {}
  if (!C) { document.getElementById('view').innerHTML = '<p style="padding:40px">Không tải được nội dung.</p>'; return; }
  render();
})();
})();
