<?php
/**
 * LT&C website API — chạy trên hosting PHP 7.4+ (cPanel, DirectAdmin, v.v.).
 *
 *   Công khai : ?action=lead (nhận form liên hệ), ?action=ping
 *   Quản trị  : login, logout, password, save, upload, leads, lead_delete, settings, settings_save, backups
 *
 * Dữ liệu riêng (mật khẩu, khách hàng để lại, cài đặt) lưu trong thư mục data/ dưới dạng file .php
 * có dòng chặn đầu file, nên không ai đọc trực tiếp được qua trình duyệt, kể cả trên Nginx.
 */
declare(strict_types=1);

const DEFAULT_PASSWORD = 'LTC@2026';          // chỉ dùng cho lần đăng nhập đầu tiên, sau đó bắt buộc đổi
const MAX_CONTENT_BYTES = 3 * 1024 * 1024;
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const KEEP_BACKUPS = 30;

define('ROOT', __DIR__);
define('DATA', __DIR__ . '/data');
define('CONTENT', __DIR__ . '/content.json');
define('UPLOADS', __DIR__ . '/uploads');
const GUARD = "<?php http_response_code(404); exit; ?>\n";

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('ltc_admin');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict', 'secure' => $https]);
session_start();

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function out(array $a, int $code = 200): void { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail(string $msg, int $code = 400): void { out(['ok' => false, 'error' => $msg], $code); }

function ensure_data_dir(): void {
    if (!is_dir(DATA)) { @mkdir(DATA, 0750, true); }
    if (!is_dir(DATA . '/backups')) { @mkdir(DATA . '/backups', 0750, true); }
    if (!is_file(DATA . '/.htaccess')) { @file_put_contents(DATA . '/.htaccess', "Require all denied\nDeny from all\n"); }
    if (!is_file(DATA . '/index.html')) { @file_put_contents(DATA . '/index.html', ''); }
}
/* Private store: JSON in a .php file behind an exit guard. */
function pread(string $name, $default) {
    $f = DATA . '/' . $name . '.php';
    if (!is_file($f)) return $default;
    $raw = (string)file_get_contents($f);
    $raw = substr($raw, strlen(GUARD));
    $j = json_decode($raw, true);
    return $j === null ? $default : $j;
}
function pwrite(string $name, $data): void {
    $f = DATA . '/' . $name . '.php';
    $tmp = $f . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, GUARD . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) fail('Không ghi được dữ liệu. Kiểm tra quyền ghi thư mục data/.', 500);
    rename($tmp, $f);
}
function body(): array {
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}
function client_key(): string { return hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|ltc'); }
function rate_limit(string $bucket, int $max, int $window): void {
    $all = pread('rate', []);
    $now = time(); $k = $bucket . ':' . client_key();
    $hits = array_values(array_filter($all[$k] ?? [], fn($t) => $t > $now - $window));
    if (count($hits) >= $max) fail('Bạn thao tác quá nhanh. Vui lòng thử lại sau ít phút.', 429);
    $hits[] = $now; $all[$k] = $hits;
    foreach ($all as $kk => $v) { if (!array_filter($v, fn($t) => $t > $now - 86400)) unset($all[$kk]); }
    pwrite('rate', $all);
}
function auth_record(): array {
    $a = pread('auth', null);
    if (!$a) { $a = ['hash' => password_hash(DEFAULT_PASSWORD, PASSWORD_DEFAULT), 'must_change' => true]; pwrite('auth', $a); }
    return $a;
}
function require_admin(): void {
    if (empty($_SESSION['ltc_ok'])) fail('Phiên đăng nhập đã hết. Vui lòng đăng nhập lại.', 401);
    $tok = $_SERVER['HTTP_X_CSRF'] ?? '';
    if (!is_string($tok) || !hash_equals((string)($_SESSION['csrf'] ?? ''), $tok)) fail('Phiên không hợp lệ. Tải lại trang quản trị.', 403);
    if (($_SESSION['last'] ?? 0) < time() - 4 * 3600) { session_destroy(); fail('Phiên đăng nhập đã hết. Vui lòng đăng nhập lại.', 401); }
    $_SESSION['last'] = time();
}
function require_post(): void { if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') fail('Phương thức không hợp lệ.', 405); }
function clean_str($v, int $max = 2000): string {
    $s = is_scalar($v) ? (string)$v : '';
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s) ?? '';
    return mb_substr(trim($s), 0, $max);
}

ensure_data_dir();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'ping':
    $ok = !empty($_SESSION['ltc_ok']);
    out(['ok' => true, 'php' => true, 'auth' => $ok, 'csrf' => $ok ? $_SESSION['csrf'] : null,
         'must_change' => $ok ? (bool)(auth_record()['must_change'] ?? false) : null,
         'writable' => is_writable(CONTENT) && is_writable(DATA)]);

case 'login':
    require_post();
    rate_limit('login', 8, 900);
    $b = body(); $a = auth_record();
    if (!password_verify((string)($b['password'] ?? ''), $a['hash'])) fail('Mật khẩu không đúng.', 401);
    session_regenerate_id(true);
    $_SESSION['ltc_ok'] = 1; $_SESSION['csrf'] = bin2hex(random_bytes(24)); $_SESSION['last'] = time();
    out(['ok' => true, 'csrf' => $_SESSION['csrf'], 'must_change' => (bool)($a['must_change'] ?? false)]);

case 'logout':
    $_SESSION = []; session_destroy(); out(['ok' => true]);

case 'password':
    require_post(); require_admin();
    $b = body(); $a = auth_record();
    if (!password_verify((string)($b['old'] ?? ''), $a['hash'])) fail('Mật khẩu hiện tại không đúng.');
    $new = (string)($b['new'] ?? '');
    if (mb_strlen($new) < 10) fail('Mật khẩu mới cần ít nhất 10 ký tự.');
    if ($new === DEFAULT_PASSWORD) fail('Hãy chọn mật khẩu khác mật khẩu mặc định.');
    pwrite('auth', ['hash' => password_hash($new, PASSWORD_DEFAULT), 'must_change' => false, 'changed' => date('c')]);
    out(['ok' => true]);

case 'save':
    require_post(); require_admin();
    $raw = (string)file_get_contents('php://input');
    if (strlen($raw) > MAX_CONTENT_BYTES) fail('Nội dung quá lớn.');
    $b = json_decode($raw, true);
    $c = $b['content'] ?? null;
    foreach (['site', 'experts', 'cases', 'news', 'logos', 'solutions', 'domains', 'industries'] as $k) {
        if (!is_array($c) || !array_key_exists($k, $c)) fail('Thiếu mục "' . $k . '" trong nội dung.');
    }
    if (is_file(CONTENT)) {
        @copy(CONTENT, DATA . '/backups/content-' . date('Ymd-His') . '.json');
        $files = glob(DATA . '/backups/content-*.json') ?: [];
        rsort($files);
        foreach (array_slice($files, KEEP_BACKUPS) as $old) @unlink($old);
    }
    $c['updatedAt'] = date('c');
    $json = json_encode($c, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    $tmp = CONTENT . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, $json, LOCK_EX) === false) fail('Không ghi được content.json. Kiểm tra quyền ghi.', 500);
    rename($tmp, CONTENT);
    out(['ok' => true, 'updatedAt' => $c['updatedAt']]);

case 'backups':
    require_admin();
    $files = glob(DATA . '/backups/content-*.json') ?: []; rsort($files);
    out(['ok' => true, 'items' => array_map(fn($f) => ['name' => basename($f), 'size' => filesize($f)], $files)]);

case 'restore':
    require_post(); require_admin();
    $name = basename((string)(body()['name'] ?? ''));
    $f = DATA . '/backups/' . $name;
    if (!preg_match('/^content-\d{8}-\d{6}\.json$/', $name) || !is_file($f)) fail('Không tìm thấy bản sao lưu.');
    $j = json_decode((string)file_get_contents($f), true);
    if (!is_array($j)) fail('Bản sao lưu bị lỗi.');
    out(['ok' => true, 'content' => $j]);

case 'upload':
    require_post(); require_admin();
    $f = $_FILES['file'] ?? null;
    if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) fail('Tải ảnh không thành công.');
    if ($f['size'] > MAX_UPLOAD_BYTES) fail('Ảnh vượt quá 5 MB. Hãy nén ảnh trước khi tải lên.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext || @getimagesize($f['tmp_name']) === false) fail('Chỉ nhận ảnh JPG, PNG hoặc WEBP.');
    $folder = preg_replace('/[^a-z]/', '', (string)($_POST['folder'] ?? 'misc')) ?: 'misc';
    if (!in_array($folder, ['team', 'logos', 'news', 'cases', 'misc'], true)) $folder = 'misc';
    $dir = UPLOADS . '/' . $folder;
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_file(UPLOADS . '/.htaccess')) @file_put_contents(UPLOADS . '/.htaccess', "<FilesMatch \"\\.(php|phtml|phar|pl|py|cgi|sh)$\">\nRequire all denied\n</FilesMatch>\nOptions -Indexes\n");
    $name = date('Ymd') . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) fail('Không lưu được ảnh. Kiểm tra quyền ghi thư mục uploads/.', 500);
    @chmod($dir . '/' . $name, 0644);
    out(['ok' => true, 'path' => 'uploads/' . $folder . '/' . $name]);

case 'lead':
    require_post();
    $b = body();
    if (!empty($b['website'])) out(['ok' => true]);           // bẫy chống spam: bot điền ô ẩn
    rate_limit('lead', 6, 600);
    $allowed = ['type', 'lang', 'page', 'name', 'org', 'role', 'phone', 'email', 'industry', 'need', 'msg'];
    $lead = ['id' => bin2hex(random_bytes(8)), 'createdAt' => date('c'), 'status' => 'new'];
    foreach ($allowed as $k) $lead[$k] = clean_str($b[$k] ?? '', $k === 'msg' ? 4000 : 300);
    if (isset($b['scores']) && is_array($b['scores'])) $lead['scores'] = array_map(fn($v) => is_numeric($v) ? (int)$v : null, array_slice($b['scores'], 0, 5, true));
    if ($lead['name'] === '' || ($lead['email'] === '' && $lead['phone'] === '')) fail('Thiếu họ tên hoặc thông tin liên hệ.');
    if ($lead['email'] !== '' && !filter_var($lead['email'], FILTER_VALIDATE_EMAIL)) fail('Email không hợp lệ.');
    $fp = fopen(DATA . '/leads.lock', 'c'); flock($fp, LOCK_EX);
    $leads = pread('leads', []); array_unshift($leads, $lead); pwrite('leads', array_slice($leads, 0, 5000));
    flock($fp, LOCK_UN); fclose($fp);
    $set = pread('settings', []);
    $to = trim((string)($set['notify_email'] ?? ''));
    if ($to !== '' && filter_var($to, FILTER_VALIDATE_EMAIL) && function_exists('mail')) {
        $labels = ['type' => 'Nguồn', 'name' => 'Họ tên', 'org' => 'Tổ chức', 'role' => 'Chức danh', 'phone' => 'Điện thoại', 'email' => 'Email', 'industry' => 'Lĩnh vực', 'need' => 'Quan tâm', 'msg' => 'Nội dung'];
        $txt = "Khách hàng mới để lại thông tin trên website LT&C:\n\n";
        foreach ($labels as $k => $l) if (($lead[$k] ?? '') !== '') $txt .= $l . ': ' . $lead[$k] . "\n";
        if (!empty($lead['scores'])) $txt .= 'Điểm Smart Review 360: ' . json_encode($lead['scores']) . "\n";
        $host = preg_replace('/[^a-z0-9.\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
        $headers = "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nFrom: LT&C Website <no-reply@" . $host . ">\r\n";
        if ($lead['email'] !== '') $headers .= 'Reply-To: ' . $lead['email'] . "\r\n";
        @mail($to, '=?UTF-8?B?' . base64_encode('[Website] ' . $lead['name'] . ' – ' . $lead['org']) . '?=', $txt, $headers);
    }
    out(['ok' => true]);

case 'leads':
    require_admin();
    out(['ok' => true, 'items' => pread('leads', [])]);

case 'lead_update':
    require_post(); require_admin();
    $b = body(); $id = (string)($b['id'] ?? '');
    $fp = fopen(DATA . '/leads.lock', 'c'); flock($fp, LOCK_EX);
    $leads = pread('leads', []);
    if (!empty($b['delete'])) { $leads = array_values(array_filter($leads, fn($l) => ($l['id'] ?? '') !== $id)); }
    else { foreach ($leads as &$l) if (($l['id'] ?? '') === $id) { $l['status'] = clean_str($b['status'] ?? 'new', 20); $l['note'] = clean_str($b['note'] ?? '', 1000); } unset($l); }
    pwrite('leads', $leads);
    flock($fp, LOCK_UN); fclose($fp);
    out(['ok' => true]);

case 'settings':
    require_admin();
    out(['ok' => true, 'settings' => pread('settings', ['notify_email' => ''])]);

case 'settings_save':
    require_post(); require_admin();
    $b = body(); $to = clean_str($b['notify_email'] ?? '', 200);
    if ($to !== '' && !filter_var($to, FILTER_VALIDATE_EMAIL)) fail('Email nhận thông báo không hợp lệ.');
    pwrite('settings', ['notify_email' => $to]);
    out(['ok' => true]);

default:
    fail('Không có thao tác này.', 404);
}
