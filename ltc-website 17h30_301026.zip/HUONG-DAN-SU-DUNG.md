# Website LT&C – Hướng dẫn đưa lên tên miền và quản trị

## 1. Bộ file gồm những gì

| File / thư mục | Vai trò |
|---|---|
| `index.html` | Trang web (một trang, chuyển mục bằng menu) |
| `assets/` | Giao diện (`site.css`) và chương trình (`site.js`) |
| `content.json` | **Toàn bộ nội dung**: chuyên gia, dự án, tin tức, logo, liên hệ, mạng xã hội… Trang quản trị sửa file này |
| `admin/` | Trang quản trị: `tenmien.vn/admin/` |
| `api.php` | Nhận form khách hàng, đăng nhập quản trị, lưu nội dung, tải ảnh |
| `img/` | Ảnh chuyên gia, logo, ảnh hoạt động |
| `uploads/` | Ảnh tải lên từ trang quản trị |
| `data/` | Dữ liệu riêng: mật khẩu, danh sách khách hàng để lại, bản sao lưu. Đã được chặn truy cập từ bên ngoài |

## 2. Đưa lên hosting (cPanel / DirectAdmin / Plesk)

1. Hosting cần **PHP 7.4 trở lên** (gần như mọi gói hosting Việt Nam đều có).
2. Vào **File Manager** → thư mục `public_html` (hoặc thư mục của tên miền).
3. Tải file `ltc-website.zip` lên → bấm **Extract** (giải nén). Đảm bảo `index.html` nằm ngay trong `public_html`, không nằm trong thư mục con.
4. Phân quyền ghi (thường hosting đã đặt sẵn, chỉ làm nếu báo lỗi khi lưu):
   - `content.json` → 644 (hoặc 664)
   - thư mục `data/` và `uploads/` → 755 (hoặc 775)
5. Bật **SSL (https)** cho tên miền trong cPanel (AutoSSL / Let’s Encrypt).
6. Mở `https://tenmien.vn` để kiểm tra, rồi mở `https://tenmien.vn/admin/`.

> Hosting chạy Nginx (không đọc `.htaccess`): dữ liệu riêng vẫn an toàn vì được lưu trong file `.php` có dòng chặn. Có thể nhờ kỹ thuật chặn thêm thư mục `data/backups/`.

## 3. Đăng nhập quản trị lần đầu

- Địa chỉ: `https://tenmien.vn/admin/`
- Mật khẩu mặc định: **`LTC@2026`**
- Ngay sau khi đăng nhập: vào **Sao lưu & cài đặt → Đổi mật khẩu** (ít nhất 10 ký tự). Hệ thống sẽ nhắc cho đến khi đổi.
- Cũng trong mục đó: nhập **email nhận thông báo** để mỗi khi có khách để lại thông tin, hệ thống gửi email (hosting cần hỗ trợ gửi mail; nếu không nhận được, vẫn xem đầy đủ trong mục "Khách hàng để lại").

## 4. Các việc thường làm

| Việc | Vào mục | Cách làm |
|---|---|---|
| Thêm / sửa chuyên gia, đổi ảnh | Chuyên gia | Bấm tên → sửa → **Tải ảnh lên** (ảnh dọc 4:5) |
| Ẩn tạm một chuyên gia (vd. bà Hồng Nhung) | Chuyên gia | Tích / bỏ tích **Ẩn khỏi website** |
| Đưa chuyên gia vào vòng tròn 7 lĩnh vực | Vòng tròn lĩnh vực | Chọn lĩnh vực → tích tên chuyên gia |
| Thêm dự án, case study | Dự án | **+ Thêm** → điền bối cảnh, 4 bước 4D, **kết quả bằng con số**, trích dẫn khách hàng, chọn chuyên gia |
| Đưa dự án lên trang chủ | Dự án | Tích **Hiện ở trang chủ** (tối đa 3) |
| Đăng tin, bài báo chí | Tin tức & Báo chí | **+ Thêm** → chọn loại (Tin LT&C / Sự kiện / Báo chí / Góc nhìn), dán link bài gốc |
| Thêm logo khách hàng | Logo khách hàng | **+ Thêm** → chọn nhóm → tải PNG nền trong suốt |
| Sửa hotline, email, địa chỉ, Zalo OA, YouTube, Fanpage | Thông tin chung | Điền link đầy đủ `https://…`; để trống thì biểu tượng tự ẩn |
| Xem khách hàng để lại thông tin | Khách hàng để lại | Đổi trạng thái (Mới / Đã liên hệ / Đã chốt), **Tải Excel (CSV)** |

Sau khi sửa: bấm **Lưu & xuất bản** (góc trên bên phải). Website cập nhật ngay.
Mỗi lần lưu, hệ thống tự giữ bản cũ (30 bản gần nhất) trong **Sao lưu & cài đặt → Khôi phục**.

## 5. Không có PHP thì sao?

Website vẫn chạy bình thường (chỉ cần `index.html`, `assets/`, `content.json`, `img/`). Khi đó:
- Trang quản trị chạy ở **chế độ xem thử**: sửa xong bấm **Tải content.json**, rồi tải file này lên hosting ghi đè file cũ.
- Form liên hệ sẽ báo khách gọi hotline/email, vì không có nơi lưu. Nên dùng hosting có PHP.

## 6. Cần LT&C bổ sung

- [ ] Kết quả bằng con số và trích dẫn của khách hàng cho 3 dự án JCI (mục Dự án → "Kết quả bằng con số").
- [ ] Thời gian, trạng thái từng dự án.
- [ ] Link Zalo OA, kênh YouTube, Fanpage (mục Thông tin chung).
- [ ] Bài báo chí viết về LT&C (mục Tin tức → mục mẫu đang ẩn "[Mẫu] Tên bài báo…").
- [ ] Xác nhận 2 tin đã điền sẵn: Lễ ký MOU với BV Ung Bướu An Giang (09/10/2026) và khóa "Làm báo cáo với AI" cho VAMED (18/09/2026).
- [ ] Nguồn gốc của số liệu "hơn 80% mục tiêu không đạt do thực thi".
